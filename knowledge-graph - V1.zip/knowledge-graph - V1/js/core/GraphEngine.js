import * as THREE from 'three';
import { EventBus } from './EventBus.js';
import { SceneManager } from './SceneManager.js';
import { LayoutManager } from './LayoutManager.js';
import { SelectionManager } from './SelectionManager.js';
import { NodeRenderer } from '../renderers/NodeRenderer.js';
import { LinkRenderer } from '../renderers/LinkRenderer.js';
import { LabelRenderer } from '../renderers/LabelRenderer.js';
import { ModelRenderer } from '../renderers/ModelRenderer.js';
import { CameraController } from '../interaction/CameraController.js';
import { DragManager } from '../interaction/DragManager.js';
import { InteractionManager } from '../interaction/InteractionManager.js';
import { NODE_TYPES } from '../utils/Constants.js';

/**
 * Public entry point of the Q3D library. Instantiate one per canvas.
 *
 *   const g = new GraphEngine({ container: '#graph', data, models: {…} });
 *   await g.load();
 *   g.expandNode(id); g.showPath(a, b); ...
 *
 * Responsibilities:
 *   - own the shared EventBus
 *   - construct scene, renderers, layout, selection, interaction
 *   - drive the animation loop
 *   - expose the documented public API
 */
export class GraphEngine {
    constructor(opts = {}) {
        this.container = typeof opts.container === 'string'
            ? document.querySelector(opts.container)
            : opts.container;
        if (!this.container) throw new Error('GraphEngine: container element not found');
        this.labelsRoot = typeof opts.labelsRoot === 'string'
            ? document.querySelector(opts.labelsRoot)
            : (opts.labelsRoot || this.container);

        this.bus = opts.bus || new EventBus();
        this.data = opts.data || { nodes: [], relations: [] };
        this.layoutMode = opts.layout || 'force';
        this.theme = opts.theme || 'light';
        this.modelMap = opts.models || {};
        this.fetchChildren = opts.fetchChildren || null; // async(id) => {nodes,relations}

        this.nodes = [];
        this.links = [];
        this._collapsedChildren = new Map(); // parentId -> {nodes, links} (branches removed from live graph)

        this._buildSubsystems();
        this._wire();
    }

    _buildSubsystems() {
        this.scene = new SceneManager(this.container, { theme: this.theme, bus: this.bus });
        this.modelRenderer = new ModelRenderer({ modelMap: this.modelMap });
        this.selection = new SelectionManager({ bus: this.bus });
        this.layout = new LayoutManager({ bus: this.bus });
        this.nodeRenderer = new NodeRenderer({
            scene: this.scene.nodeGroup,
            bus: this.bus,
            selection: this.selection,
            modelRenderer: this.modelRenderer
        });
        this.linkRenderer = new LinkRenderer({
            scene: this.scene.linkGroup,
            particleGroup: this.scene.particleGroup,
            bus: this.bus,
            selection: this.selection
        });
        this.labelRenderer = new LabelRenderer({
            container: this.labelsRoot,
            camera: this.scene.camera,
            nodes: [],
            selection: this.selection,
            bus: this.bus
        });
        this.cameraController = new CameraController({
            camera: this.scene.camera,
            renderer: this.scene.renderer,
            bus: this.bus
        });
        this.drag = new DragManager({
            renderer: this.scene.renderer,
            camera: this.scene.camera,
            cameraController: this.cameraController,
            layout: this.layout,
            bus: this.bus
        });
        this.interaction = new InteractionManager({
            renderer: this.scene.renderer,
            camera: this.scene.camera,
            bus: this.bus,
            nodes: this.nodes,
            dragManager: this.drag,
            cameraController: this.cameraController
        });

        this.layout.onTick(() => {
            // no per-frame work here — renderers read node.x/y/z on render.
        });
    }

    _wire() {
        // clicking a node selects it & opens info panel
        this.bus.on('nodeClick', ({ node, additive }) => {
            this.selection.select(node.id, { additive });
        });
        this.bus.on('nodeDoubleClick', (node) => {
            this.cameraController.centerNode(node);
        });
        this.bus.on('backgroundClick', () => {
            this.selection.clearSelection();
            this.selection.clearHighlight();
        });

        // when a node is moved by drag, keep pinned unless user un-pins later
        this.bus.on('nodeMoved', (n) => {
            this.bus.emit('layoutDirty');
        });
    }

    /* =====================================================
     * Public API
     * ===================================================== */

    async load() {
        this._ingest(this.data);
        this.nodeRenderer.setData(this.nodes);
        // rebuild labels only after node meshes exist so radii are known
        this.labelRenderer.setData(this.nodes);
        this.linkRenderer.setData(this.nodes, this.links);
        this.selection.setGraph(this.nodes, this.links);
        this.layout.setData(this.nodes, this.links);
        this.layout.setMode(this.layoutMode);
        this.nodeRenderer.refreshStatus();
        this._startLoop();
        this.bus.emit('graphLoaded', { nodes: this.nodes.length, links: this.links.length });
        // fit view after a small delay so force layout has some progress
        setTimeout(() => this.fitGraph(), 250);
    }

    /** Replace the entire graph with new data. */
    setData(data) {
        this.data = data;
        this._ingest(data);
        this.nodeRenderer.setData(this.nodes);
        this.labelRenderer.setData(this.nodes);
        this.linkRenderer.setData(this.nodes, this.links);
        this.selection.setGraph(this.nodes, this.links);
        this.layout.setData(this.nodes, this.links);
        this.layout.setMode(this.layoutMode);
        this.nodeRenderer.refreshStatus();
        this.bus.emit('graphLoaded', { nodes: this.nodes.length, links: this.links.length });
    }

    _ingest(data) {
        // clone to avoid mutating the caller's data
        this.nodes = (data.nodes || []).map(n => ({
            ...n,
            x: n.x ?? (Math.random() - 0.5) * 60,
            y: n.y ?? (Math.random() - 0.5) * 20,
            z: n.z ?? (Math.random() - 0.5) * 60,
            _originalStatus: n.status,
            status: n.status || 'unknown'
        }));
        const map = new Map(this.nodes.map(n => [n.id, n]));
        this.links = (data.relations || data.links || []).map((l, i) => ({
            id: l.id || `l_${i}`,
            source: map.get(l.source) || l.source,
            target: map.get(l.target) || l.target,
            type: l.type || 'dependsOn',
            properties: l.properties || {}
        })).filter(l => typeof l.source === 'object' && typeof l.target === 'object');

        // give interaction the fresh list
        this.interaction.setNodes(this.nodes);
    }

    setLayout(mode) {
        this.layoutMode = mode;
        this.layout.setMode(mode);
    }

    setTheme(name) {
        this.theme = name;
        this.scene.applyTheme(name);
    }

    async expandNode(id) {
        const stash = this._collapsedChildren.get(id);
        if (stash) {
            // restore collapsed children
            this.nodes.push(...stash.nodes);
            this.links.push(...stash.links);
            this._collapsedChildren.delete(id);
        } else if (this.fetchChildren) {
            const res = await this.fetchChildren(id);
            if (res?.nodes?.length) {
                // give them a starting position near the parent
                const parent = this.nodes.find(n => n.id === id);
                for (const n of res.nodes) {
                    if (this.nodes.some(x => x.id === n.id)) continue;
                    n.x = parent.x + (Math.random() - 0.5) * 30;
                    n.y = parent.y + 10 + Math.random() * 6;
                    n.z = parent.z + (Math.random() - 0.5) * 30;
                    n._originalStatus = n.status;
                    n.status = n.status || 'unknown';
                    this.nodes.push(n);
                }
                const map = new Map(this.nodes.map(n => [n.id, n]));
                for (const l of (res.relations || res.links || [])) {
                    this.links.push({
                        id: l.id || `l_${this.links.length}`,
                        source: map.get(l.source) || l.source,
                        target: map.get(l.target) || l.target,
                        type: l.type || 'dependsOn',
                        properties: l.properties || {}
                    });
                }
            }
        }
        await this._refreshAll();
        this.bus.emit('onExpand', id);
    }

    async collapseNode(id) {
        // BFS out from `id` gathering descendants that only reach this branch
        const removed = new Set();
        const queue = [id];
        const rootSet = new Set([id]);
        while (queue.length) {
            const cur = queue.shift();
            for (const l of this.links) {
                const s = l.source.id, t = l.target.id;
                if (s === cur && !rootSet.has(t) && !removed.has(t)) {
                    removed.add(t); queue.push(t);
                }
            }
        }
        if (!removed.size) return;
        const removedNodes = this.nodes.filter(n => removed.has(n.id));
        const removedLinks = this.links.filter(l => removed.has(l.source.id) || removed.has(l.target.id));
        this._collapsedChildren.set(id, { nodes: removedNodes, links: removedLinks });
        this.nodes = this.nodes.filter(n => !removed.has(n.id));
        this.links = this.links.filter(l => !removedLinks.includes(l));
        await this._refreshAll();
        this.bus.emit('onCollapse', id);
    }

    async _refreshAll() {
        this.nodeRenderer.setData(this.nodes);
        this.labelRenderer.setData(this.nodes);
        this.linkRenderer.setData(this.nodes, this.links);
        this.selection.setGraph(this.nodes, this.links);
        this.layout.setData(this.nodes, this.links);
        this.layout.setMode(this.layoutMode);
        this.nodeRenderer.refreshStatus();
        this.interaction.setNodes(this.nodes);
    }

    search(query) {
        if (!query) { this.selection.clearHighlight(); return []; }
        const q = query.toLowerCase();
        const hits = this.nodes.filter(n =>
            (n.id && String(n.id).toLowerCase().includes(q)) ||
            (n.name && String(n.name).toLowerCase().includes(q)) ||
            (n.type && String(n.type).toLowerCase().includes(q)) ||
            (n.status && String(n.status).toLowerCase().includes(q)) ||
            (n.properties && Object.values(n.properties).some(v => String(v).toLowerCase().includes(q)))
        );
        this.selection.highlight(hits.map(n => n.id));
        this.bus.emit('onSearch', { query, hits });
        if (hits.length === 1) this.cameraController.centerNode(hits[0]);
        else if (hits.length > 1) this.cameraController.fitTo(hits);
        return hits;
    }

    showPath(a, b) { return this.selection.showPath(a, b); }

    centerNode(id) {
        const n = this.nodes.find(nn => nn.id === id);
        if (n) this.cameraController.centerNode(n);
    }

    fitGraph() { this.cameraController.fitTo(this.nodes); }

    getNode(id) { return this.nodes.find(n => n.id === id); }

    /** Simulate a node failure — used by demo "Simulate failure" toolbar button. */
    failNode(id) { this.selection.markFailed(id); this.nodeRenderer.refreshStatus(); }
    restoreNode(id) { this.selection.restore(id); this.nodeRenderer.refreshStatus(); }

    _startLoop() {
        const loop = () => {
            this._rafHandle = requestAnimationFrame(loop);
            const dt = this.scene.clock.getDelta();
            const elapsed = this.scene.clock.elapsedTime;
            this.cameraController.update();
            this.nodeRenderer.update(dt, elapsed);
            this.linkRenderer.update(dt);
            this.labelRenderer.update();
            this.scene.render();
            this._frame = (this._frame || 0) + 1;
            const now = performance.now();
            if (!this._fpsAt || now - this._fpsAt > 500) {
                const fps = Math.round(this._frame / ((now - (this._fpsAt || now)) / 1000)) || 0;
                this.bus.emit('fps', fps);
                this._frame = 0; this._fpsAt = now;
            }
        };
        this._rafHandle = requestAnimationFrame(loop);
    }

    destroy() {
        cancelAnimationFrame(this._rafHandle);
        this.interaction.dispose();
        this.cameraController.dispose();
        this.labelRenderer.dispose();
        this.linkRenderer.dispose();
        this.nodeRenderer.dispose();
        this.modelRenderer.dispose();
        this.layout.dispose();
        this.scene.dispose();
        this.bus.clear();
    }
}
