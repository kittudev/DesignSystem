/**
 * Tiny pub/sub. All Q3D subsystems communicate through one instance of this.
 *
 * Rationale for using a bus (vs direct calls):
 *   - the UI, camera, selection, and renderers all react to the same events
 *     (nodeClick, nodeSelected, cameraMove, ...). A bus keeps them decoupled.
 */
export class EventBus {
    constructor() {
        this._listeners = new Map(); // event -> Set<fn>
    }

    on(event, fn) {
        if (!this._listeners.has(event)) this._listeners.set(event, new Set());
        this._listeners.get(event).add(fn);
        return () => this.off(event, fn);
    }

    once(event, fn) {
        const off = this.on(event, (...args) => { off(); fn(...args); });
        return off;
    }

    off(event, fn) {
        this._listeners.get(event)?.delete(fn);
    }

    emit(event, payload) {
        const set = this._listeners.get(event);
        if (!set) return;
        // copy to allow safe removal during dispatch
        for (const fn of Array.from(set)) {
            try { fn(payload); }
            catch (e) { console.error(`[EventBus] listener for "${event}" threw:`, e); }
        }
    }

    clear() { this._listeners.clear(); }
}
