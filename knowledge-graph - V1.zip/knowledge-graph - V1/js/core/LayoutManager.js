import * as d3 from 'd3-force-3d';
import * as THREE from 'three';
import { fibSphere, clamp } from '../utils/Helpers.js';

/**
 * Computes 3D positions for nodes. Supports several layouts. Only one layout
 * is "live" (force) — the rest deterministically place then let physics settle.
 *
 * All layouts write to node.x / node.y / node.z (the same fields d3-force-3d
 * mutates), so switching layouts is uniform.
 */
export class LayoutManager {
    constructor({ bus }) {
        this.bus = bus;
        this.sim = null;
        this.mode = 'force';
        this.nodes = [];
        this.links = [];
        this.running = false;
        this.pinned = new Set();
        this.tickCallback = null;
    }

    setData(nodes, links) {
        this.nodes = nodes;
        this.links = links;
    }

    onTick(cb) { this.tickCallback = cb; }

    pin(nodeId, x, y, z) {
        this.pinned.add(nodeId);
        const n = this.nodes.find(n => n.id === nodeId);
        if (!n) return;
        n.fx = x; n.fy = y; n.fz = z;
    }

    unpin(nodeId) {
        this.pinned.delete(nodeId);
        const n = this.nodes.find(n => n.id === nodeId);
        if (!n) return;
        n.fx = n.fy = n.fz = null;
    }

    setMode(mode) {
        this.mode = mode;
        this.stop();
        switch (mode) {
            case 'force':          this._runForce();          break;
            case 'tree':           this._layoutTree();        break;
            case 'hierarchy':      this._layoutHierarchy();   break;
            case 'radial':         this._layoutRadial();      break;
            case 'infrastructure': this._layoutInfrastructure(); break;
            case 'circular':       this._layoutCircular();    break;
            case 'manual':         /* no-op */                break;
        }
        this.bus?.emit('layoutChanged', mode);
    }

    stop() {
        if (this.sim) { this.sim.stop(); this.sim = null; }
        this.running = false;
    }

    reheat(alpha = 0.6) {
        if (this.sim) this.sim.alpha(alpha).restart();
    }

    /* ---------- FORCE ---------- */
    _runForce() {
        this.sim = d3.forceSimulation(this.nodes, 3)
            .force('charge', d3.forceManyBody().strength(-120).distanceMax(400))
            .force('link', d3.forceLink(this.links).id(d => d.id).distance(l => l.distance || 26).strength(0.35))
            .force('center', d3.forceCenter(0, 0, 0).strength(0.05))
            .force('collide', d3.forceCollide().radius(d => (d._radius || 5) + 1).iterations(2))
            .alpha(1).alphaDecay(0.028).velocityDecay(0.35)
            .on('tick', () => this.tickCallback?.())
            .on('end', () => { this.running = false; this.bus?.emit('layoutSettled'); });
        this.running = true;
    }

    /* ---------- TREE (top-down levels via BFS from roots) ---------- */
    _layoutTree() {
        const levels = this._computeLevels();
        const groups = new Map();
        for (const [id, lvl] of levels) {
            if (!groups.has(lvl)) groups.set(lvl, []);
            groups.get(lvl).push(id);
        }
        const spacingY = 46, spacingX = 34;
        for (const [lvl, ids] of groups) {
            const y = -lvl * spacingY + 40;
            ids.forEach((id, i) => {
                const n = this.nodes.find(nn => nn.id === id);
                if (!n) return;
                n.x = (i - (ids.length - 1) / 2) * spacingX;
                n.y = y;
                n.z = 0;
            });
        }
        this.tickCallback?.();
    }

    /* ---------- HIERARCHY (like tree but stacked with tighter siblings) ---------- */
    _layoutHierarchy() {
        this._layoutTree();
        // gentle side-shift by index to avoid horizontal alignment strip
        this.nodes.forEach((n, i) => { n.z = ((i * 17) % 60) - 30; });
        this.tickCallback?.();
    }

    /* ---------- RADIAL ---------- */
    _layoutRadial() {
        const levels = this._computeLevels();
        const perLevel = new Map();
        for (const [id, lvl] of levels) {
            if (!perLevel.has(lvl)) perLevel.set(lvl, []);
            perLevel.get(lvl).push(id);
        }
        for (const [lvl, ids] of perLevel) {
            const r = lvl === 0 ? 0 : lvl * 60;
            ids.forEach((id, i) => {
                const n = this.nodes.find(nn => nn.id === id);
                if (!n) return;
                const a = (i / ids.length) * Math.PI * 2;
                n.x = Math.cos(a) * r;
                n.z = Math.sin(a) * r;
                n.y = lvl * 12;
            });
        }
        this.tickCallback?.();
    }

    /* ---------- INFRASTRUCTURE (grid of racks over a floor plan) ---------- */
    _layoutInfrastructure() {
        // group nodes by their `zone` property if present, else by type.
        const groups = new Map();
        for (const n of this.nodes) {
            const key = n.zone || n.subnet || n.type || 'default';
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(n);
        }
        const keys = [...groups.keys()];
        const cols = Math.ceil(Math.sqrt(keys.length));
        const cellSize = 90;
        keys.forEach((k, gi) => {
            const gx = (gi % cols - (cols - 1) / 2) * cellSize;
            const gz = (Math.floor(gi / cols) - (cols - 1) / 2) * cellSize;
            const arr = groups.get(k);
            const inner = Math.ceil(Math.sqrt(arr.length));
            const step = clamp(70 / (inner + 1), 10, 20);
            arr.forEach((n, i) => {
                n.x = gx + ((i % inner) - (inner - 1) / 2) * step;
                n.z = gz + (Math.floor(i / inner) - (inner - 1) / 2) * step;
                n.y = 0;
            });
        });
        this.tickCallback?.();
    }

    /* ---------- CIRCULAR ---------- */
    _layoutCircular() {
        const radius = clamp(this.nodes.length * 3.5, 40, 260);
        this.nodes.forEach((n, i) => {
            const a = (i / this.nodes.length) * Math.PI * 2;
            n.x = Math.cos(a) * radius;
            n.z = Math.sin(a) * radius;
            n.y = 0;
        });
        this.tickCallback?.();
    }

    /* ---------- helpers ---------- */
    _computeLevels() {
        // BFS from nodes with in-degree 0
        const inDeg = new Map(this.nodes.map(n => [n.id, 0]));
        for (const l of this.links) {
            const t = typeof l.target === 'object' ? l.target.id : l.target;
            inDeg.set(t, (inDeg.get(t) || 0) + 1);
        }
        const roots = [...inDeg].filter(([, d]) => d === 0).map(([id]) => id);
        if (!roots.length && this.nodes.length) roots.push(this.nodes[0].id);
        const lvl = new Map(roots.map(id => [id, 0]));
        const adj = new Map();
        for (const l of this.links) {
            const s = typeof l.source === 'object' ? l.source.id : l.source;
            const t = typeof l.target === 'object' ? l.target.id : l.target;
            if (!adj.has(s)) adj.set(s, []);
            adj.get(s).push(t);
        }
        const q = [...roots];
        while (q.length) {
            const id = q.shift();
            const d = lvl.get(id);
            for (const nb of (adj.get(id) || [])) {
                if (!lvl.has(nb)) { lvl.set(nb, d + 1); q.push(nb); }
            }
        }
        // any remaining orphans go on level 0
        for (const n of this.nodes) if (!lvl.has(n.id)) lvl.set(n.id, 0);
        return lvl;
    }

    dispose() {
        this.stop();
        this.nodes = this.links = null;
    }
}
