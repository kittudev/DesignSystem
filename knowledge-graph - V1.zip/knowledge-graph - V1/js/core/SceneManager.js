import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { THEMES, CAMERA, RENDER } from '../utils/Constants.js';

/**
 * Owns THREE.js infra: renderer, scene, camera, lights, floor, fog, bloom.
 * Nothing here knows about graph data — pure environment.
 */
export class SceneManager {
    constructor(container, { theme = 'light', bus }) {
        this.container = container;
        this.bus = bus;
        this.themeName = theme;
        this.clock = new THREE.Clock();

        this._buildRenderer();
        this._buildScene();
        this._buildCamera();
        this._buildLights();
        this._buildFloor();
        this._buildPost();
        this.applyTheme(theme);

        this._resizeHandler = () => this.resize();
        window.addEventListener('resize', this._resizeHandler);
    }

    _buildRenderer() {
        const r = new THREE.WebGLRenderer({
            antialias: true,
            alpha: true,
            powerPreference: 'high-performance'
        });
        r.setPixelRatio(Math.min(window.devicePixelRatio, RENDER.maxPixelRatio));
        r.setSize(this.container.clientWidth, this.container.clientHeight);
        r.outputColorSpace = THREE.SRGBColorSpace;
        r.toneMapping = THREE.ACESFilmicToneMapping;
        r.toneMappingExposure = 1.0;
        r.shadowMap.enabled = true;
        r.shadowMap.type = THREE.PCFSoftShadowMap;
        this.container.appendChild(r.domElement);
        this.renderer = r;
    }

    _buildScene() {
        this.scene = new THREE.Scene();
        // group holders keep the traversal cheap
        this.rootGroup = new THREE.Group();          // everything graph-related
        this.envGroup  = new THREE.Group();          // floor, grid, ambient decor
        this.linkGroup = new THREE.Group();          // link segments
        this.particleGroup = new THREE.Group();      // travelling particles
        this.nodeGroup = new THREE.Group();          // node meshes
        this.effectGroup = new THREE.Group();        // status rings, halos

        this.scene.add(this.envGroup);
        this.scene.add(this.rootGroup);
        this.rootGroup.add(this.linkGroup);
        this.rootGroup.add(this.particleGroup);
        this.rootGroup.add(this.nodeGroup);
        this.rootGroup.add(this.effectGroup);
    }

    _buildCamera() {
        const w = this.container.clientWidth, h = this.container.clientHeight;
        this.camera = new THREE.PerspectiveCamera(CAMERA.fov, w / h, CAMERA.near, CAMERA.far);
        this.camera.position.set(180, 140, 180);
        this.camera.lookAt(0, 0, 0);
    }

    _buildLights() {
        this.ambient = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(this.ambient);

        this.hemi = new THREE.HemisphereLight(0xffffff, 0xc8d0dc, 0.55);
        this.scene.add(this.hemi);

        this.sun = new THREE.DirectionalLight(0xffffff, 1.0);
        this.sun.position.set(140, 200, 90);
        this.sun.castShadow = true;
        this.sun.shadow.mapSize.set(2048, 2048);
        this.sun.shadow.camera.near = 20;
        this.sun.shadow.camera.far = 620;
        this.sun.shadow.camera.left = -260;
        this.sun.shadow.camera.right = 260;
        this.sun.shadow.camera.top = 260;
        this.sun.shadow.camera.bottom = -260;
        this.sun.shadow.bias = -0.0005;
        this.scene.add(this.sun);

        this.rim = new THREE.DirectionalLight(0xa9c6ff, 0.35);
        this.rim.position.set(-120, 60, -180);
        this.scene.add(this.rim);
    }

    _buildFloor() {
        // Big planar floor with layered grid (major + minor) — gives an "inside a
        // virtual infrastructure" feel similar to Azure Resource Graph 3D views.
        const size = 1200;
        const floorGeo = new THREE.PlaneGeometry(size, size);
        const floorMat = new THREE.MeshStandardMaterial({
            color: 0xdfe6f0,
            roughness: 0.92,
            metalness: 0.03,
            transparent: true,
            opacity: 0.98
        });
        this.floor = new THREE.Mesh(floorGeo, floorMat);
        this.floor.rotation.x = -Math.PI / 2;
        this.floor.position.y = -14;
        this.floor.receiveShadow = true;
        this.envGroup.add(this.floor);

        // grid lines (two layers)
        this.gridMinor = new THREE.GridHelper(size, 240, 0xb4c1d8, 0xd6dfec);
        this.gridMinor.position.y = -13.99;
        this.gridMinor.material.transparent = true;
        this.gridMinor.material.opacity = 0.45;
        this.envGroup.add(this.gridMinor);

        this.gridMajor = new THREE.GridHelper(size, 24, 0x8ea1c3, 0xa9b7cf);
        this.gridMajor.position.y = -13.98;
        this.gridMajor.material.transparent = true;
        this.gridMajor.material.opacity = 0.55;
        this.envGroup.add(this.gridMajor);

        // subtle horizon glow ring
        const ringGeo = new THREE.RingGeometry(340, 480, 96);
        const ringMat = new THREE.MeshBasicMaterial({
            color: 0xa9c6ff,
            transparent: true,
            opacity: 0.16,
            side: THREE.DoubleSide,
            depthWrite: false
        });
        this.horizon = new THREE.Mesh(ringGeo, ringMat);
        this.horizon.rotation.x = -Math.PI / 2;
        this.horizon.position.y = -13.5;
        this.envGroup.add(this.horizon);
    }

    _buildPost() {
        const size = new THREE.Vector2(this.container.clientWidth, this.container.clientHeight);
        this.composer = new EffectComposer(this.renderer);
        this.composer.addPass(new RenderPass(this.scene, this.camera));
        this.bloom = new UnrealBloomPass(size, 0.5, 0.6, 0.85);
        this.composer.addPass(this.bloom);
        this.composer.addPass(new OutputPass());
    }

    applyTheme(name) {
        const t = THEMES[name] || THEMES.light;
        this.themeName = name;
        this.scene.background = new THREE.Color(t.bg);
        this.scene.fog = new THREE.Fog(t.fog, 340, 1400);
        this.floor.material.color.setHex(t.floor);
        this.gridMinor.material.color.setHex(t.gridB);
        this.gridMinor.material.opacity = name === 'dark' ? 0.20 : 0.45;
        this.gridMajor.material.color.setHex(t.gridA);
        this.gridMajor.material.opacity = name === 'dark' ? 0.28 : 0.55;
        this.ambient.color.setHex(t.ambient);
        this.ambient.intensity = name === 'dark' ? 0.35 : 0.6;
        this.hemi.intensity = name === 'dark' ? 0.4 : 0.55;
        this.sun.color.setHex(t.sun);
        this.sun.intensity = name === 'dark' ? 0.7 : 1.0;
        this.rim.color.setHex(t.rim);
        this.horizon.material.color.setHex(t.rim);
        this.bloom.strength = name === 'dark' ? 0.85 : 0.5;
        this.bus?.emit('themeChanged', name);
    }

    resize() {
        const w = this.container.clientWidth, h = this.container.clientHeight;
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
        this.composer.setSize(w, h);
    }

    render() {
        this.composer.render();
    }

    dispose() {
        window.removeEventListener('resize', this._resizeHandler);
        this.renderer.dispose();
        this.container.removeChild(this.renderer.domElement);
    }
}
