import { computeImpact, classifyLinks, bfsShortestPath, buildAdjacency } from '../utils/Helpers.js';

/**
 * Tracks selected nodes and computes derived sets used by renderers:
 *   - selected: user-picked nodes (multi-select w/ shift)
 *   - highlighted: search results
 *   - failed: nodes with status === 'down' or 'critical'
 *   - impacted: nodes reachable from failed (rendered dim/orange)
 *   - deadLinks: links touching a failed node (no particle traffic)
 *   - pathHighlight: shortest path when showPath() is called
 */
export class SelectionManager {
    constructor({ bus }) {
        this.bus = bus;
        this.selected = new Set();
        this.highlighted = new Set();
        this.failed = new Set();
        this.impacted = new Set();
        this.deadLinks = new Set();
        this.pathHighlight = null; // { nodes:Set, links:Set }
        this.nodes = [];
        this.links = [];
    }

    setGraph(nodes, links) {
        this.nodes = nodes;
        this.links = links;
        this.recomputeFailures();
    }

    /* ---- selection ---- */
    select(id, { additive = false } = {}) {
        if (!additive) this.selected.clear();
        if (id != null) this.selected.add(id);
        this.bus?.emit('selectionChanged', [...this.selected]);
    }

    deselect(id) {
        this.selected.delete(id);
        this.bus?.emit('selectionChanged', [...this.selected]);
    }

    clearSelection() {
        this.selected.clear();
        this.pathHighlight = null;
        this.bus?.emit('selectionChanged', []);
    }

    isSelected(id) { return this.selected.has(id); }

    /* ---- search highlight ---- */
    highlight(ids) {
        this.highlighted = new Set(ids);
        this.bus?.emit('highlightChanged', [...this.highlighted]);
    }

    clearHighlight() {
        this.highlighted.clear();
        this.bus?.emit('highlightChanged', []);
    }

    /* ---- failure impact ----
     * A node is "failed" if status === 'down' or 'critical'.
     * "Impacted" nodes are those which depend on a failed node (transitively).
     * Renderers use these sets to dim/red-flag nodes and stop particle traffic.
     */
    recomputeFailures() {
        this.failed.clear();
        for (const n of this.nodes) {
            if (n.status === 'down' || n.status === 'critical') this.failed.add(n.id);
        }
        this.impacted = computeImpact(this.failed, this.nodes, this.links);
        // remove failed set from impacted so the two are disjoint
        for (const id of this.failed) this.impacted.delete(id);
        this.deadLinks = classifyLinks(this.links, this.failed);
        this.bus?.emit('failuresChanged', {
            failed: [...this.failed],
            impacted: [...this.impacted],
            deadLinks: this.deadLinks.size
        });
    }

    markFailed(id) {
        const n = this.nodes.find(nn => nn.id === id);
        if (!n) return;
        n.status = 'down';
        this.recomputeFailures();
    }

    restore(id) {
        const n = this.nodes.find(nn => nn.id === id);
        if (!n) return;
        n.status = n._originalStatus || 'healthy';
        this.recomputeFailures();
    }

    /* ---- path highlight ---- */
    showPath(aId, bId) {
        const adj = buildAdjacency(this.nodes, this.links);
        const path = bfsShortestPath(aId, bId, adj);
        if (!path) { this.pathHighlight = null; this.bus?.emit('pathChanged', null); return null; }
        const linkSet = new Set();
        for (let i = 0; i < path.length - 1; i++) {
            const a = path[i], b = path[i + 1];
            const l = this.links.find(l => {
                const s = typeof l.source === 'object' ? l.source.id : l.source;
                const t = typeof l.target === 'object' ? l.target.id : l.target;
                return (s === a && t === b) || (s === b && t === a);
            });
            if (l) linkSet.add(l);
        }
        this.pathHighlight = { nodes: new Set(path), links: linkSet };
        this.bus?.emit('pathChanged', { path, links: [...linkSet] });
        return path;
    }

    clearPath() {
        this.pathHighlight = null;
        this.bus?.emit('pathChanged', null);
    }

    /* ---- serialization for renderers ---- */
    getState() {
        return {
            selected: this.selected,
            highlighted: this.highlighted,
            failed: this.failed,
            impacted: this.impacted,
            deadLinks: this.deadLinks,
            pathHighlight: this.pathHighlight
        };
    }
}
