import * as THREE from 'three';

/** Small util grab-bag. Pure functions only. */

export function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

export function lerp(a, b, t) { return a + (b - a) * t; }

/** ease-in-out cubic */
export function easeInOut(t) {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

/** Return a debounced version of a function. */
export function debounce(fn, wait = 100) {
    let h = null;
    return (...args) => {
        clearTimeout(h);
        h = setTimeout(() => fn(...args), wait);
    };
}

export function throttle(fn, wait = 60) {
    let last = 0;
    return (...args) => {
        const now = performance.now();
        if (now - last >= wait) { last = now; fn(...args); }
    };
}

export function uniqueId(prefix = 'id') {
    return prefix + '_' + Math.random().toString(36).slice(2, 9);
}

/** Simple 2D→NDC projection helper for label placement. */
export function projectToScreen(vec3, camera, width, height, out = { x: 0, y: 0, visible: true }) {
    const v = vec3.clone().project(camera);
    out.visible = v.z < 1 && v.z > -1;
    out.x = (v.x * 0.5 + 0.5) * width;
    out.y = (-v.y * 0.5 + 0.5) * height;
    return out;
}

/** BFS reachability. Returns Set of nodeIds reachable from `startIds`, walking `edges` (id→[id]). */
export function bfsReachable(startIds, adj) {
    const seen = new Set(startIds);
    const q = [...startIds];
    while (q.length) {
        const id = q.shift();
        const outs = adj.get(id);
        if (!outs) continue;
        for (const n of outs) {
            if (!seen.has(n)) { seen.add(n); q.push(n); }
        }
    }
    return seen;
}

/** Shortest path via BFS (unweighted). Returns array of ids or null. */
export function bfsShortestPath(startId, endId, adj) {
    if (startId === endId) return [startId];
    const prev = new Map();
    const seen = new Set([startId]);
    const q = [startId];
    while (q.length) {
        const id = q.shift();
        const outs = adj.get(id);
        if (!outs) continue;
        for (const n of outs) {
            if (seen.has(n)) continue;
            seen.add(n);
            prev.set(n, id);
            if (n === endId) {
                const path = [n];
                let cur = n;
                while (prev.has(cur)) { cur = prev.get(cur); path.unshift(cur); }
                return path;
            }
            q.push(n);
        }
    }
    return null;
}

/** Build both-directions adjacency Map<id, Set<id>>. */
export function buildAdjacency(nodes, links, { directed = false } = {}) {
    const adj = new Map();
    for (const n of nodes) adj.set(n.id, new Set());
    for (const l of links) {
        const s = typeof l.source === 'object' ? l.source.id : l.source;
        const t = typeof l.target === 'object' ? l.target.id : l.target;
        adj.get(s)?.add(t);
        if (!directed) adj.get(t)?.add(s);
    }
    return adj;
}

/** Build outgoing-only adjacency for directional impact analysis. */
export function buildOutAdjacency(nodes, links) {
    return buildAdjacency(nodes, links, { directed: true });
}

/** Given failed nodeIds and an outgoing adjacency, return the set of nodes
 * that become "impacted" — those which depend (transitively) on a failed node.
 * Impact = reachable in reverse from failed set. */
export function computeImpact(failedIds, nodes, links) {
    // reverse the outgoing graph: if A depends on B and B fails, A is impacted
    const rev = new Map();
    for (const n of nodes) rev.set(n.id, new Set());
    for (const l of links) {
        const s = typeof l.source === 'object' ? l.source.id : l.source;
        const t = typeof l.target === 'object' ? l.target.id : l.target;
        // "dependsOn / connectsTo / hosts / routes" all indicate s->t traffic.
        // If t fails, s cannot function. So we walk t -> s in the reverse map.
        rev.get(t)?.add(s);
    }
    return bfsReachable(failedIds, rev);
}

/** For a failure map (Set<failedId>), classify which links are broken. */
export function classifyLinks(links, failedSet) {
    const out = new Set();
    for (const l of links) {
        const s = typeof l.source === 'object' ? l.source.id : l.source;
        const t = typeof l.target === 'object' ? l.target.id : l.target;
        if (failedSet.has(s) || failedSet.has(t)) out.add(l);
    }
    return out;
}

/** Compact a hex color int for CSS. */
export function hexCss(n) {
    return '#' + n.toString(16).padStart(6, '0');
}

/** Distance-in-radians heuristic for sphere layouts. */
export function fibSphere(i, total, radius = 1) {
    const phi = Math.acos(1 - 2 * (i + 0.5) / total);
    const theta = Math.PI * (1 + Math.sqrt(5)) * i;
    return new THREE.Vector3(
        Math.cos(theta) * Math.sin(phi) * radius,
        Math.sin(theta) * Math.sin(phi) * radius,
        Math.cos(phi) * radius
    );
}
