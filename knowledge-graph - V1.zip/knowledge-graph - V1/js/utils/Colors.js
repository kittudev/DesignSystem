import * as THREE from 'three';
import { STATUS_META, NODE_TYPES } from './Constants.js';

/**
 * Color helpers. All colors are stored as 24-bit ints in constants; this
 * module produces THREE.Color instances and utility mixers.
 */

export function statusColor(status) {
    const meta = STATUS_META[status] || STATUS_META.unknown;
    return new THREE.Color(meta.color);
}

export function statusHex(status) {
    const meta = STATUS_META[status] || STATUS_META.unknown;
    return '#' + meta.color.toString(16).padStart(6, '0');
}

/** Pick a base body color for a node type (softens surface, status is overlay). */
export function typeSurfaceColor(type) {
    const surface = {
        vm:          0xf3f6fc,
        server:      0xe7ecf5,
        database:    0xdde5f2,
        storage:     0xe4e9f3,
        region:      0xdae5f7,
        vpc:         0xe0e9f8,
        subnet:      0xdfe7f4,
        loadbalancer:0xe5edf9,
        router:      0xe5edf9,
        gateway:     0xe5edf9,
        service:     0xecf1fa,
        container:   0xeaf0fa,
        user:        0xf1f4fb,
        unknown:     0xeaf0fa
    };
    return new THREE.Color(surface[type] ?? surface.unknown);
}

/** Emissive tint used when a node's status color is glowing. */
export function statusEmissive(status, intensity = 1.0) {
    const c = statusColor(status);
    return c.multiplyScalar(intensity);
}

export function mix(a, b, t) {
    return new THREE.Color(a).lerp(new THREE.Color(b), t);
}

/** Softer link color when a link is inactive/failed. */
export function linkColorFor(relType, failed, meta) {
    if (failed) return new THREE.Color(STATUS_META.critical.color);
    return new THREE.Color(meta.color);
}
