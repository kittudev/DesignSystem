/**
 * Global constants used by Q3D. No runtime logic — pure data.
 */

export const NODE_TYPES = Object.freeze({
    vm:          { shape: 'rack',    scale: 1.0,  label: 'VM' },
    server:      { shape: 'rack',    scale: 1.1,  label: 'Server' },
    database:    { shape: 'cylinder',scale: 1.0,  label: 'Database' },
    storage:     { shape: 'disk',    scale: 0.9,  label: 'Storage' },
    region:      { shape: 'globe',   scale: 1.6,  label: 'Region' },
    vpc:         { shape: 'cloud',   scale: 1.4,  label: 'VPC' },
    subnet:      { shape: 'hexagon', scale: 1.0,  label: 'Subnet' },
    loadbalancer:{ shape: 'diamond', scale: 1.0,  label: 'Load Balancer' },
    router:      { shape: 'diamond', scale: 1.0,  label: 'Router' },
    gateway:     { shape: 'diamond', scale: 1.0,  label: 'Gateway' },
    service:     { shape: 'sphere',  scale: 0.85, label: 'Service' },
    container:   { shape: 'cube',    scale: 0.85, label: 'Container' },
    user:        { shape: 'sphere',  scale: 0.7,  label: 'User' },
    unknown:     { shape: 'sphere',  scale: 1.0,  label: 'Unknown' }
});

export const STATUS_META = Object.freeze({
    healthy:     { label: 'Healthy',     color: 0x28a76f, effect: 'glow'  },
    warning:     { label: 'Warning',     color: 0xd99a1c, effect: 'pulse' },
    critical:    { label: 'Critical',    color: 0xde3b3b, effect: 'pulse' },
    down:        { label: 'Down',        color: 0x8592a8, effect: 'dead'  },
    maintenance: { label: 'Maintenance', color: 0x2f89ff, effect: 'ring'  },
    overloaded:  { label: 'Overloaded',  color: 0xff7a2f, effect: 'heat'  },
    unknown:     { label: 'Unknown',     color: 0x6a7a94, effect: 'none'  }
});

export const RELATION_META = Object.freeze({
    contains:     { color: 0x8ea1c3, thickness: 0.10, arrow: false, animated: false, particles: 0 },
    dependsOn:    { color: 0x2f6bff, thickness: 0.12, arrow: true,  animated: true,  particles: 3 },
    hosts:        { color: 0x00b3a7, thickness: 0.11, arrow: true,  animated: true,  particles: 2 },
    connectsTo:   { color: 0x7a5cff, thickness: 0.12, arrow: true,  animated: true,  particles: 4 },
    replicatesTo: { color: 0x28a76f, thickness: 0.11, arrow: true,  animated: true,  particles: 5 },
    belongsTo:    { color: 0x8592a8, thickness: 0.09, arrow: false, animated: false, particles: 0 },
    routes:       { color: 0xff7a2f, thickness: 0.12, arrow: true,  animated: true,  particles: 3 }
});

export const LAYOUTS = Object.freeze([
    { id: 'force',          label: 'Force' },
    { id: 'tree',           label: 'Tree' },
    { id: 'hierarchy',      label: 'Hierarchy' },
    { id: 'radial',         label: 'Radial' },
    { id: 'infrastructure', label: 'Infrastructure' },
    { id: 'circular',       label: 'Circular' },
    { id: 'manual',         label: 'Manual' }
]);

export const CAMERA = Object.freeze({
    fov: 45,
    near: 0.1,
    far: 4000,
    defaultDistance: 220,
    minDistance: 10,
    maxDistance: 1600,
    flyDuration: 900
});

export const RENDER = Object.freeze({
    maxPixelRatio: 2,
    labelMinScreenDist: 900,
    labelMaxCount: 260,
    lodNearDistance: 320,
    particleSpeed: 24
});

export const THEMES = Object.freeze({
    light: {
        bg: 0xeef3fb,
        fog: 0xe6ecf5,
        floor: 0xdfe6f0,
        gridA: 0xb4c1d8,
        gridB: 0xd6dfec,
        ambient: 0xffffff,
        sun: 0xfff6e0,
        rim: 0xa9c6ff
    },
    dusk: {
        bg: 0xd7dee9,
        fog: 0xc8d1e0,
        floor: 0xbcc6d6,
        gridA: 0x8a9bb8,
        gridB: 0xc0cadb,
        ambient: 0xf3f6fb,
        sun: 0xffd9a3,
        rim: 0x88a9dc
    },
    dark: {
        bg: 0x0b1220,
        fog: 0x0e1730,
        floor: 0x0f1930,
        gridA: 0x1c2b48,
        gridB: 0x24345a,
        ambient: 0x88a1cc,
        sun: 0xcadaff,
        rim: 0x8a5cff
    }
});
