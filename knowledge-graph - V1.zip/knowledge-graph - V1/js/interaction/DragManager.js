import * as THREE from 'three';

/**
 * Drag a node in 3D by projecting mouse movement onto a plane parallel to the
 * screen at the node's depth. While dragging we pin the node in the layout
 * simulation (fx/fy/fz) so the force-graph respects the user's placement, and
 * re-heat the simulation slightly so neighbors settle around it.
 */
export class DragManager {
    constructor({ renderer, camera, cameraController, layout, bus }) {
        this.renderer = renderer;
        this.camera = camera;
        this.cameraController = cameraController;
        this.layout = layout;
        this.bus = bus;

        this.node = null;
        this.plane = new THREE.Plane();
        this.hitPoint = new THREE.Vector3();
        this.offset = new THREE.Vector3();
        this._raycaster = new THREE.Raycaster();
    }

    /** Begin dragging a node. Called by InteractionManager on left-mouse-down when hitting a node. */
    begin(node, ndc) {
        if (!node) return false;
        this.node = node;
        // build a plane parallel to camera passing through the node
        const camDir = new THREE.Vector3();
        this.camera.getWorldDirection(camDir);
        this.plane.setFromNormalAndCoplanarPoint(camDir, new THREE.Vector3(node.x, node.y, node.z));
        // offset from ray hit to node position — keeps grab point consistent
        this._raycaster.setFromCamera(ndc, this.camera);
        if (this._raycaster.ray.intersectPlane(this.plane, this.hitPoint)) {
            this.offset.copy(new THREE.Vector3(node.x, node.y, node.z)).sub(this.hitPoint);
        } else {
            this.offset.set(0, 0, 0);
        }

        // pin & disable orbit controls while dragging
        this.cameraController.controls.enabled = false;
        this.layout.pin(node.id, node.x, node.y, node.z);
        this.layout.reheat(0.4);
        this.bus?.emit('dragStart', node);
        return true;
    }

    move(ndc) {
        if (!this.node) return;
        this._raycaster.setFromCamera(ndc, this.camera);
        const p = new THREE.Vector3();
        if (!this._raycaster.ray.intersectPlane(this.plane, p)) return;
        p.add(this.offset);
        this.node.x = p.x; this.node.y = p.y; this.node.z = p.z;
        this.node.fx = p.x; this.node.fy = p.y; this.node.fz = p.z;
        this.layout.reheat(0.15);
        this.bus?.emit('nodeMoved', this.node);
    }

    end() {
        if (!this.node) return;
        const n = this.node;
        // release pin unless user held shift (interaction manager passes flag on end)
        this.cameraController.controls.enabled = true;
        this.bus?.emit('dragEnd', n);
        this.node = null;
    }

    cancel() {
        if (this.node) {
            this.layout.unpin(this.node.id);
            this.cameraController.controls.enabled = true;
            this.node = null;
        }
    }

    get active() { return this.node !== null; }
}
