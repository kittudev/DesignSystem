import * as THREE from 'three';

/**
 * Pointer-and-keyboard router. Owns the Raycaster and translates DOM events
 * into semantic events on the bus:
 *   - nodeClick, nodeDoubleClick, nodeHover, nodeContextMenu
 *   - background clicks clear selection
 * Delegates dragging to DragManager once a drag threshold is crossed.
 */
export class InteractionManager {
    constructor({ renderer, camera, bus, nodes, dragManager, cameraController }) {
        this.renderer = renderer;
        this.camera = camera;
        this.bus = bus;
        this.nodes = nodes;
        this.drag = dragManager;
        this.cameraController = cameraController;
        this.raycaster = new THREE.Raycaster();
        this.raycaster.params.Line.threshold = 0.5;
        this.ndc = new THREE.Vector2();

        this._downNode = null;
        this._downPos = null;
        this._dragThreshold = 4; // px before we consider it a drag
        this._lastClickTime = 0;
        this._lastClickNode = null;
        this._hoverNode = null;

        this._bind();
    }

    setNodes(nodes) { this.nodes = nodes; }

    _bind() {
        const el = this.renderer.domElement;
        el.addEventListener('pointerdown', this._onDown = (e) => this._down(e));
        window.addEventListener('pointermove', this._onMove = (e) => this._move(e));
        window.addEventListener('pointerup', this._onUp = (e) => this._up(e));
        el.addEventListener('contextmenu', this._onCtx = (e) => this._ctx(e));
        el.addEventListener('pointerleave', this._onLeave = () => this._leave());
        el.style.touchAction = 'none';
    }

    _updateNdc(e) {
        const r = this.renderer.domElement.getBoundingClientRect();
        this.ndc.x = ((e.clientX - r.left) / r.width) * 2 - 1;
        this.ndc.y = -((e.clientY - r.top) / r.height) * 2 + 1;
    }

    _pickNode() {
        this.raycaster.setFromCamera(this.ndc, this.camera);
        // build list of node meshes on demand — nodes list is short
        const targets = [];
        for (const n of this.nodes) {
            if (n.mesh) targets.push(n.mesh);
        }
        // recursive: model meshes may have children
        const hits = this.raycaster.intersectObjects(targets, true);
        if (!hits.length) return null;
        // walk up to node group carrying nodeId
        let obj = hits[0].object;
        while (obj && !obj.userData?.isNode) obj = obj.parent;
        if (!obj) return null;
        return this.nodes.find(n => n.id === obj.userData.nodeId) || null;
    }

    _down(e) {
        this._updateNdc(e);
        const node = this._pickNode();
        this._downNode = node;
        this._downPos = { x: e.clientX, y: e.clientY, time: performance.now(), button: e.button, shift: e.shiftKey };
    }

    _move(e) {
        this._updateNdc(e);
        if (this.drag.active) {
            this.drag.move(this.ndc);
            return;
        }
        // check drag threshold
        if (this._downNode && this._downPos && this._downPos.button === 0) {
            const dx = e.clientX - this._downPos.x;
            const dy = e.clientY - this._downPos.y;
            if (dx * dx + dy * dy > this._dragThreshold * this._dragThreshold) {
                this.drag.begin(this._downNode, this.ndc);
            }
            return;
        }
        // hover
        const node = this._pickNode();
        if (node !== this._hoverNode) {
            this._hoverNode = node;
            this.renderer.domElement.style.cursor = node ? 'pointer' : 'default';
            this.bus?.emit('nodeHover', node);
        }
    }

    _up(e) {
        if (this.drag.active) {
            this.drag.end();
            this._downNode = null; this._downPos = null;
            return;
        }
        if (!this._downPos) return;
        const dt = performance.now() - this._downPos.time;
        const dx = e.clientX - this._downPos.x;
        const dy = e.clientY - this._downPos.y;
        const moved = dx * dx + dy * dy > 9;
        this._updateNdc(e);
        const node = this._pickNode();

        if (this._downPos.button === 0 && !moved) {
            if (node) {
                // double click?
                const now = performance.now();
                if (this._lastClickNode === node && now - this._lastClickTime < 300) {
                    this.bus?.emit('nodeDoubleClick', node);
                    this._lastClickNode = null;
                } else {
                    this.bus?.emit('nodeClick', { node, additive: this._downPos.shift });
                    this._lastClickNode = node;
                    this._lastClickTime = now;
                }
            } else {
                this.bus?.emit('backgroundClick');
                this._lastClickNode = null;
            }
        }
        this._downNode = null; this._downPos = null;
    }

    _ctx(e) {
        e.preventDefault();
        this._updateNdc(e);
        const node = this._pickNode();
        if (node) this.bus?.emit('nodeContextMenu', { node, x: e.clientX, y: e.clientY });
        else this.bus?.emit('backgroundContextMenu', { x: e.clientX, y: e.clientY });
    }

    _leave() {
        if (this._hoverNode) { this._hoverNode = null; this.bus?.emit('nodeHover', null); }
    }

    dispose() {
        const el = this.renderer.domElement;
        el.removeEventListener('pointerdown', this._onDown);
        window.removeEventListener('pointermove', this._onMove);
        window.removeEventListener('pointerup', this._onUp);
        el.removeEventListener('contextmenu', this._onCtx);
        el.removeEventListener('pointerleave', this._onLeave);
    }
}
