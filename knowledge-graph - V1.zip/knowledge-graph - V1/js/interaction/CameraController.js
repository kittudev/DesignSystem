import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CAMERA } from '../utils/Constants.js';
import { easeInOut } from '../utils/Helpers.js';

/**
 * Wraps OrbitControls and adds smooth "fly-to" animations for centerNode,
 * fitGraph, and zoomToSelection. Emits `cameraMove` on the bus during
 * both user drags and animated tweens.
 */
export class CameraController {
    constructor({ camera, renderer, bus }) {
        this.camera = camera;
        this.renderer = renderer;
        this.bus = bus;

        this.controls = new OrbitControls(camera, renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.09;
        this.controls.minDistance = CAMERA.minDistance;
        this.controls.maxDistance = CAMERA.maxDistance;
        this.controls.maxPolarAngle = Math.PI * 0.495; // don't go under floor
        this.controls.rotateSpeed = 0.75;
        this.controls.zoomSpeed = 0.9;
        this.controls.panSpeed = 0.8;
        this.controls.screenSpacePanning = false;
        this.controls.target.set(0, 0, 0);
        this.controls.addEventListener('change', () => this.bus?.emit('cameraMove', {
            position: camera.position.clone(),
            target: this.controls.target.clone()
        }));

        // active fly-to tween
        this._tween = null;
    }

    /** Smoothly fly camera+target to a new state. */
    flyTo(targetPos, cameraPos, duration = CAMERA.flyDuration) {
        return new Promise((resolve) => {
            const startCam = this.camera.position.clone();
            const startTgt = this.controls.target.clone();
            const endCam = cameraPos.clone();
            const endTgt = targetPos.clone();
            const startTime = performance.now();
            this._tween = { resolve };

            const step = () => {
                if (!this._tween) return; // canceled
                const t = Math.min(1, (performance.now() - startTime) / duration);
                const e = easeInOut(t);
                this.camera.position.lerpVectors(startCam, endCam, e);
                this.controls.target.lerpVectors(startTgt, endTgt, e);
                this.controls.update();
                if (t < 1) requestAnimationFrame(step);
                else { this._tween = null; resolve(); }
            };
            step();
        });
    }

    cancelTween() {
        if (this._tween) {
            this._tween.resolve();
            this._tween = null;
        }
    }

    /** Center a specific node — used by double-click / info-panel button. */
    centerNode(node, distance = 45) {
        if (!node) return;
        const tgt = new THREE.Vector3(node.x, node.y, node.z);
        // preserve current viewing direction
        const dir = new THREE.Vector3().subVectors(this.camera.position, this.controls.target).normalize();
        const cam = tgt.clone().add(dir.multiplyScalar(distance));
        this.flyTo(tgt, cam);
    }

    /** Fit all provided points into the view frustum. */
    fitTo(points, padding = 1.6) {
        if (!points.length) return;
        const box = new THREE.Box3();
        for (const p of points) box.expandByPoint(new THREE.Vector3(p.x, p.y, p.z));
        const size = box.getSize(new THREE.Vector3());
        const center = box.getCenter(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z, 20);
        const fov = this.camera.fov * (Math.PI / 180);
        const dist = (maxDim / (2 * Math.tan(fov / 2))) * padding;
        const dir = new THREE.Vector3(0.7, 0.55, 0.8).normalize();
        const cam = center.clone().add(dir.multiplyScalar(dist));
        this.flyTo(center, cam);
    }

    reset() {
        this.flyTo(new THREE.Vector3(0, 0, 0), new THREE.Vector3(180, 140, 180));
    }

    update() { this.controls.update(); }

    dispose() {
        this.cancelTween();
        this.controls.dispose();
    }
}
