import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

/**
 * Optional GLB loader for per-type models. Registered models are cached; if a
 * type has no registered model, tryLoad returns null and the NodeRenderer
 * falls back to procedural geometry.
 */
export class ModelRenderer {
    constructor({ modelMap = {} } = {}) {
        this.modelMap = modelMap;      // { type: 'models/foo.glb' }
        this.cache = new Map();        // type -> cloned template mesh
        this.loader = new GLTFLoader();
        this.loading = new Map();      // type -> Promise
    }

    register(type, url) { this.modelMap[type] = url; }

    async tryLoad(type) {
        const url = this.modelMap?.[type];
        if (!url) return null;
        if (this.cache.has(type)) return this._clone(this.cache.get(type));
        if (this.loading.has(type)) {
            await this.loading.get(type);
            return this._clone(this.cache.get(type));
        }
        const p = new Promise((resolve) => {
            this.loader.load(url, (gltf) => {
                const root = gltf.scene;
                root.traverse((o) => {
                    if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; }
                });
                this.cache.set(type, root);
                resolve(root);
            }, undefined, (err) => {
                console.warn(`[ModelRenderer] failed to load ${url}`, err);
                this.cache.set(type, null);
                resolve(null);
            });
        });
        this.loading.set(type, p);
        const root = await p;
        return root ? this._clone(root) : null;
    }

    _clone(template) {
        if (!template) return null;
        // shallow clone materials as well so we can tint per node without cross-talk
        const c = template.clone(true);
        c.traverse((o) => {
            if (o.isMesh && o.material) {
                o.material = o.material.clone();
            }
        });
        return c;
    }

    dispose() {
        for (const t of this.cache.values()) {
            t?.traverse?.((o) => {
                if (o.geometry) o.geometry.dispose?.();
                if (o.material) {
                    const mats = Array.isArray(o.material) ? o.material : [o.material];
                    mats.forEach(m => m.dispose?.());
                }
            });
        }
        this.cache.clear();
    }
}
