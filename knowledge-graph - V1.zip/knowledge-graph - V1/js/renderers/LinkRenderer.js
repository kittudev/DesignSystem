import * as THREE from 'three';
import { RELATION_META } from '../utils/Constants.js';
import { linkColorFor } from '../utils/Colors.js';
import { RENDER } from '../utils/Constants.js';

/**
 * Renders links as thin tubes AND animates data packets (particles) that
 * traverse each link — the "connections moving between nodes" the user asked
 * for (replacing infinitown's cars-on-roads visual with real graph traffic).
 *
 * A link with a failed endpoint is drawn dashed/red and its particles are
 * frozen — so the viewer sees exactly which flows stopped because of a
 * failure and which downstream nodes are impacted.
 */
export class LinkRenderer {
    constructor({ scene, particleGroup, bus, selection }) {
        this.scene = scene;             // link group
        this.particleGroup = particleGroup;
        this.bus = bus;
        this.selection = selection;
        this.links = [];
        this.nodes = [];
        this._particles = [];           // [{link, t, speed, mesh, dir}]
        this._tubeGeoCache = new THREE.CylinderGeometry(1, 1, 1, 6, 1, true);
        this._particleGeo = new THREE.SphereGeometry(0.55, 8, 6);
    }

    setData(nodes, links) {
        this._clear();
        this.nodes = nodes;
        this.links = links;
        for (const l of links) this._buildLink(l);
        this.refresh();
    }

    _clear() {
        for (const l of this.links || []) {
            l.mesh?.geometry?.dispose?.();
            l.mesh?.material?.dispose?.();
            if (l.mesh) this.scene.remove(l.mesh);
        }
        for (const p of this._particles) {
            if (p.mesh) this.particleGroup.remove(p.mesh);
            p.mesh?.material?.dispose?.();
        }
        this._particles.length = 0;
    }

    _buildLink(l) {
        const meta = RELATION_META[l.type] || RELATION_META.dependsOn;

        // A curved line: sample midpoint offset for a gentle arc — feels less
        // static than straight lines and reads well under bloom.
        const geom = new THREE.BufferGeometry();
        geom.setAttribute('position', new THREE.BufferAttribute(new Float32Array(3 * 24), 3));
        const mat = new THREE.LineBasicMaterial({
            color: meta.color,
            transparent: true,
            opacity: 0.75,
            linewidth: 1
        });
        const line = new THREE.Line(geom, mat);
        line.userData = { linkId: l.id || `${l.source}-${l.target}`, isLink: true };
        this.scene.add(line);
        l.mesh = line;
        l._meta = meta;

        // build travelling particles for animated links
        const particleCount = meta.particles || 0;
        for (let i = 0; i < particleCount; i++) {
            const mat = new THREE.MeshBasicMaterial({
                color: meta.color,
                transparent: true,
                opacity: 0.95,
                depthWrite: false,
                blending: THREE.AdditiveBlending
            });
            const m = new THREE.Mesh(this._particleGeo, mat);
            m.userData = { linkId: line.userData.linkId, isParticle: true };
            this.particleGroup.add(m);
            this._particles.push({
                link: l,
                mesh: m,
                t: i / particleCount,
                speed: (0.6 + Math.random() * 0.4) * (meta.animated ? 1 : 0),
                dir: 1
            });
        }
    }

    /** Called every frame with dt seconds. Updates line geometry + particles. */
    update(dt) {
        const st = this.selection.getState();
        const failed = st.failed;
        const impacted = st.impacted;

        for (const l of this.links) {
            const s = l.source;
            const t = l.target;
            const sPos = typeof s === 'object' ? s : this._findNode(s);
            const tPos = typeof t === 'object' ? t : this._findNode(t);
            if (!sPos || !tPos || !l.mesh) continue;

            const dead = failed.has(sPos.id) || failed.has(tPos.id);
            l._dead = dead;

            // update line positions with a gentle arc
            const arr = l.mesh.geometry.attributes.position.array;
            const segs = arr.length / 3;
            const midY = (sPos.y + tPos.y) / 2 + 6;
            const mid = new THREE.Vector3(
                (sPos.x + tPos.x) / 2,
                midY,
                (sPos.z + tPos.z) / 2
            );
            const p0 = new THREE.Vector3(sPos.x, sPos.y, sPos.z);
            const p1 = new THREE.Vector3(tPos.x, tPos.y, tPos.z);
            for (let i = 0; i < segs; i++) {
                const u = i / (segs - 1);
                // quadratic bezier
                const one = 1 - u;
                const x = one * one * p0.x + 2 * one * u * mid.x + u * u * p1.x;
                const y = one * one * p0.y + 2 * one * u * mid.y + u * u * p1.y;
                const z = one * one * p0.z + 2 * one * u * mid.z + u * u * p1.z;
                arr[i * 3 + 0] = x; arr[i * 3 + 1] = y; arr[i * 3 + 2] = z;
            }
            l.mesh.geometry.attributes.position.needsUpdate = true;
            l.mesh.geometry.computeBoundingSphere();

            // color/opacity based on state
            const meta = l._meta;
            const isSelectedTouch = st.selected.has(sPos.id) || st.selected.has(tPos.id);
            const isPath = st.pathHighlight?.links?.has(l);
            const baseColor = linkColorFor(l.type, dead, meta);
            l.mesh.material.color.copy(baseColor);
            let op = 0.55;
            if (dead) op = 0.85;
            else if (isPath) op = 1.0;
            else if (isSelectedTouch) op = 0.95;
            else if (impacted.has(sPos.id) || impacted.has(tPos.id)) op = 0.35;
            l.mesh.material.opacity = op;
        }

        // move particles along their link's arc
        for (const p of this._particles) {
            const l = p.link;
            if (!l._meta?.animated || l._dead) {
                p.mesh.visible = false;
                continue;
            }
            p.mesh.visible = true;
            p.t += dt * p.speed * 0.35;
            if (p.t > 1) p.t -= 1;

            const s = typeof l.source === 'object' ? l.source : this._findNode(l.source);
            const tn = typeof l.target === 'object' ? l.target : this._findNode(l.target);
            if (!s || !tn) continue;
            const midY = (s.y + tn.y) / 2 + 6;
            const u = p.t;
            const one = 1 - u;
            p.mesh.position.set(
                one * one * s.x + 2 * one * u * ((s.x + tn.x) / 2) + u * u * tn.x,
                one * one * s.y + 2 * one * u * midY + u * u * tn.y,
                one * one * s.z + 2 * one * u * ((s.z + tn.z) / 2) + u * u * tn.z
            );
            p.mesh.material.color.copy(l.mesh.material.color);
        }
    }

    /** Re-evaluates colors when selection/failure state changes. */
    refresh() { /* handled in update loop */ }

    _findNode(id) { return this.nodes.find(n => n.id === id); }

    dispose() {
        this._clear();
        this._particleGeo.dispose();
        this._tubeGeoCache.dispose();
    }
}
