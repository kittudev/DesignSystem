import * as THREE from 'three';
import { NODE_TYPES, STATUS_META } from '../utils/Constants.js';
import { statusColor, typeSurfaceColor } from '../utils/Colors.js';

/**
 * Builds and updates the 3D meshes for every node.
 *
 * For scale, we generate a single mesh per node (not InstancedMesh) so that we
 * can support per-node shape, GLB model, status ring, etc. For >5k nodes, the
 * caller should switch on `useInstanced` and we swap to a compact fallback.
 *
 * Each node.mesh carries userData: { nodeId, type, radius }.
 */
export class NodeRenderer {
    constructor({ scene, bus, modelRenderer, selection }) {
        this.scene = scene;
        this.bus = bus;
        this.selection = selection;
        this.modelRenderer = modelRenderer;
        this.nodes = [];
        // reused geometries (shared to reduce memory pressure)
        this._geo = this._buildGeometryCache();
        // ambient rings for status effects
        this._ringGeo = new THREE.RingGeometry(1.0, 1.18, 42);
        // simple pool of glow sprites
        this._glowTexture = this._makeGlowTexture();
    }

    _buildGeometryCache() {
        return {
            rack:    new THREE.BoxGeometry(3, 6, 2),
            cube:    new THREE.BoxGeometry(3.6, 3.6, 3.6),
            cylinder:new THREE.CylinderGeometry(2.4, 2.4, 5, 24),
            disk:    new THREE.CylinderGeometry(3.2, 3.2, 1.4, 24),
            globe:   new THREE.SphereGeometry(4.5, 32, 24),
            cloud:   new THREE.IcosahedronGeometry(4.2, 1),
            hexagon: new THREE.CylinderGeometry(3, 3, 1.6, 6),
            diamond: new THREE.OctahedronGeometry(3.4, 0),
            sphere:  new THREE.SphereGeometry(2.8, 24, 18)
        };
    }

    _makeGlowTexture() {
        const c = document.createElement('canvas');
        c.width = c.height = 128;
        const ctx = c.getContext('2d');
        const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
        g.addColorStop(0.0, 'rgba(255,255,255,1)');
        g.addColorStop(0.4, 'rgba(255,255,255,0.5)');
        g.addColorStop(1.0, 'rgba(255,255,255,0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 128, 128);
        const t = new THREE.CanvasTexture(c);
        t.needsUpdate = true;
        return t;
    }

    setData(nodes) {
        this.nodes = nodes;
        this._build();
    }

    async _build() {
        // clear old
        for (const child of [...this.scene.children]) {
            child.geometry?.dispose?.();
            this.scene.remove(child);
        }
        for (const n of this.nodes) {
            const mesh = await this._buildOne(n);
            n.mesh = mesh;
            n._radius = mesh.userData.radius;
            this.scene.add(mesh);
        }
    }

    async _buildOne(n) {
        const typeSpec = NODE_TYPES[n.type] || NODE_TYPES.unknown;
        const scale = typeSpec.scale || 1.0;

        // Try model first (async). If none registered, fall back to procedural.
        const modelMesh = await this.modelRenderer.tryLoad(n.type);
        let core;
        if (modelMesh) {
            core = modelMesh;
        } else {
            const geo = this._geo[typeSpec.shape] || this._geo.sphere;
            const mat = new THREE.MeshStandardMaterial({
                color: typeSurfaceColor(n.type),
                roughness: 0.55,
                metalness: 0.22,
                emissive: statusColor(n.status).multiplyScalar(0.18),
                emissiveIntensity: 0.9
            });
            core = new THREE.Mesh(geo, mat);
            core.castShadow = true;
            core.receiveShadow = true;
        }
        core.scale.setScalar(scale);

        // Group: core + status ring + glow sprite (halo)
        const group = new THREE.Group();
        group.add(core);
        group.position.set(n.x || 0, n.y || 0, n.z || 0);

        // status ring (thin disc under the node)
        const ringMat = new THREE.MeshBasicMaterial({
            color: statusColor(n.status),
            transparent: true,
            opacity: 0.55,
            side: THREE.DoubleSide,
            depthWrite: false
        });
        const ring = new THREE.Mesh(this._ringGeo, ringMat);
        ring.rotation.x = -Math.PI / 2;
        ring.position.y = -3.4;
        ring.scale.setScalar(3.2 * scale);
        ring.userData.role = 'statusRing';
        group.add(ring);

        // glow sprite (for status pulse/glow)
        const sprMat = new THREE.SpriteMaterial({
            map: this._glowTexture,
            color: statusColor(n.status),
            transparent: true,
            opacity: 0.55,
            depthWrite: false,
            blending: THREE.AdditiveBlending
        });
        const halo = new THREE.Sprite(sprMat);
        halo.scale.setScalar(14 * scale);
        halo.userData.role = 'halo';
        group.add(halo);

        // radius for physics + label placement
        const radius = 4.6 * scale;
        group.userData = { nodeId: n.id, type: n.type, radius, isNode: true };

        return group;
    }

    /** Refresh mesh colors / effects for status changes and impact overlay. */
    refreshStatus() {
        const st = this.selection.getState();
        for (const n of this.nodes) {
            if (!n.mesh) continue;
            const s = n.status || 'unknown';
            const meta = STATUS_META[s] || STATUS_META.unknown;
            const col = statusColor(s);
            const isFailed = st.failed.has(n.id);
            const isImpact = st.impacted.has(n.id);
            const isSel = st.selected.has(n.id);
            const isHigh = st.highlighted.has(n.id);

            let core = null, ring = null, halo = null;
            for (const c of n.mesh.children) {
                if (c.userData?.role === 'statusRing') ring = c;
                else if (c.userData?.role === 'halo') halo = c;
                else core = c;
            }

            if (core?.material?.color) {
                core.material.emissive?.copy?.(col).multiplyScalar(isFailed ? 1.2 : isImpact ? 0.7 : 0.35);
                core.material.needsUpdate = true;
            }
            if (ring) {
                ring.material.color.copy(col);
                ring.material.opacity = isFailed ? 0.85 : (isSel || isHigh) ? 0.75 : 0.5;
            }
            if (halo) {
                halo.material.color.copy(col);
                halo.material.opacity = isSel ? 0.9 : isFailed ? 0.75 : 0.42;
                halo.scale.setScalar(isSel ? 22 : isFailed ? 20 : 14);
            }
            n._statusEffect = meta.effect;
            n._effectPhase = n._effectPhase || Math.random() * Math.PI * 2;
        }
    }

    /** Called every frame — small status animations (pulse/heat/glow). */
    update(dt, elapsed) {
        for (const n of this.nodes) {
            if (!n.mesh) continue;
            n.mesh.position.set(n.x, n.y, n.z);
            const effect = n._statusEffect || 'glow';
            const phase = n._effectPhase || 0;
            let ring = null, halo = null;
            for (const c of n.mesh.children) {
                if (c.userData?.role === 'statusRing') ring = c;
                else if (c.userData?.role === 'halo') halo = c;
            }
            const t = elapsed * 2 + phase;
            switch (effect) {
                case 'pulse':
                    if (halo) halo.scale.setScalar(14 + Math.sin(t) * 4);
                    if (ring) ring.scale.setScalar(3.2 + Math.sin(t) * 0.5);
                    break;
                case 'ring':
                    if (ring) ring.rotation.z += dt * 0.6;
                    break;
                case 'heat':
                    if (halo) {
                        const v = 0.5 + Math.abs(Math.sin(t * 1.5)) * 0.5;
                        halo.material.opacity = v;
                    }
                    break;
                case 'dead':
                    if (halo) halo.material.opacity = 0.15;
                    break;
                default:
                    if (halo) halo.scale.setScalar(14 + Math.sin(t * 0.6) * 1.2);
            }
        }
    }

    dispose() {
        for (const g of Object.values(this._geo)) g.dispose();
        this._ringGeo.dispose();
        this._glowTexture.dispose();
    }
}
