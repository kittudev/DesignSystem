import * as THREE from 'three';
import { NODE_TYPES } from '../utils/Constants.js';
import { statusHex } from '../utils/Colors.js';
import { projectToScreen, throttle } from '../utils/Helpers.js';
import { RENDER } from '../utils/Constants.js';

/**
 * DOM-based node labels. Cheaper than CSS3DRenderer for many nodes because
 * we only run projection math per node, then move HTML elements — GPU stays
 * on the scene.
 *
 * Labels always "face the camera" naturally (they're HTML).
 */
export class LabelRenderer {
    constructor({ container, camera, nodes, selection, bus }) {
        this.container = container;   // div where labels live
        this.camera = camera;
        this.nodes = nodes;
        this.selection = selection;
        this.bus = bus;
        this.labels = new Map();      // nodeId -> DOM element
        this.visible = true;

        this._resize = throttle(() => this._updateSize(), 100);
        window.addEventListener('resize', this._resize);
        this._updateSize();
    }

    _updateSize() {
        this.width = this.container.clientWidth;
        this.height = this.container.clientHeight;
    }

    setData(nodes) {
        this.nodes = nodes;
        // remove old
        for (const el of this.labels.values()) el.remove();
        this.labels.clear();

        for (const n of nodes) {
            const el = document.createElement('div');
            el.className = 'node-label';
            el.dataset.nodeId = n.id;
            const dot = statusHex(n.status || 'unknown');
            const typeLabel = NODE_TYPES[n.type]?.label || n.type || 'Node';
            el.innerHTML = `
                <div class="nl-title">${escapeHTML(n.name || n.id)}</div>
                <div class="nl-meta">
                    <span class="nl-status" style="background:${dot};color:${dot};"></span>
                    <span>${escapeHTML(typeLabel)}</span>
                </div>`;
            this.container.appendChild(el);
            this.labels.set(n.id, el);
        }
    }

    setVisible(v) {
        this.visible = v;
        for (const el of this.labels.values()) el.style.display = v ? '' : 'none';
    }

    /** Called per frame — cheap DOM writes only when position changes appreciably. */
    update() {
        if (!this.visible) return;
        const st = this.selection.getState();
        const cam = this.camera;
        const w = this.width, h = this.height;
        const camPos = cam.position;
        const out = { x: 0, y: 0, visible: true };

        let drawn = 0;
        // sort by distance so nearest N always draw (LOD)
        const list = this.nodes.slice().sort((a, b) => {
            const da = (a.x - camPos.x) ** 2 + (a.y - camPos.y) ** 2 + (a.z - camPos.z) ** 2;
            const db = (b.x - camPos.x) ** 2 + (b.y - camPos.y) ** 2 + (b.z - camPos.z) ** 2;
            return da - db;
        });

        for (const n of list) {
            const el = this.labels.get(n.id);
            if (!el) continue;
            const shouldShow = drawn < RENDER.labelMaxCount;
            if (!shouldShow) { el.style.display = 'none'; continue; }
            const pos = new THREE.Vector3(n.x, n.y + (n._radius || 5) + 3, n.z);
            projectToScreen(pos, cam, w, h, out);
            if (!out.visible) { el.style.display = 'none'; continue; }
            el.style.display = '';
            el.style.transform = `translate(${out.x}px, ${out.y}px) translate(-50%, -50%)`;
            drawn++;

            // classes
            const isSel = st.selected.has(n.id);
            const isFail = st.failed.has(n.id);
            const isImp = st.impacted.has(n.id);
            const isHigh = st.highlighted.has(n.id);
            el.classList.toggle('selected', isSel || isHigh);
            el.classList.toggle('failed', isFail);
            el.classList.toggle('impacted', isImp);
            el.classList.toggle('dim',
                (st.selected.size > 0 && !isSel && !isImp && !isFail) ||
                (st.highlighted.size > 0 && !isHigh));
        }
    }

    dispose() {
        window.removeEventListener('resize', this._resize);
        for (const el of this.labels.values()) el.remove();
        this.labels.clear();
    }
}

function escapeHTML(s) {
    return String(s ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}
