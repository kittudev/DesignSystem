import { statusHex } from '../utils/Colors.js';
import { NODE_TYPES } from '../utils/Constants.js';
import { debounce } from '../utils/Helpers.js';

/**
 * Search input + suggestion dropdown. Uses engine.search() for the actual
 * matching so the highlight/fit behavior stays consistent.
 */
export class SearchPanel {
    constructor({ input, results, engine, bus }) {
        this.input = input;
        this.results = results;
        this.engine = engine;
        this.bus = bus;

        this._onInput = debounce(() => this._runSearch(), 120);
        this.input.addEventListener('input', this._onInput);
        this.input.addEventListener('focus', () => this._runSearch(true));
        this.input.addEventListener('keydown', (e) => this._onKey(e));
        document.addEventListener('click', (e) => {
            if (!this.results.contains(e.target) && e.target !== this.input) this.results.classList.remove('visible');
        });
    }

    _runSearch(showAllIfEmpty = false) {
        const q = this.input.value.trim();
        if (!q) {
            if (showAllIfEmpty) this._render(this.engine.nodes.slice(0, 30));
            else { this.results.classList.remove('visible'); this.engine.selection.clearHighlight(); }
            return;
        }
        const hits = this.engine.search(q);
        this._render(hits.slice(0, 40));
    }

    _render(list) {
        if (!list.length) {
            this.results.innerHTML = `<div class="search-result-item" style="opacity:0.6;">No matches</div>`;
            this.results.classList.add('visible');
            return;
        }
        this.results.innerHTML = list.map(n => {
            const typeLabel = NODE_TYPES[n.type]?.label || n.type;
            return `
                <div class="search-result-item" data-id="${escapeAttr(n.id)}">
                    <span class="sr-dot" style="background:${statusHex(n.status)};box-shadow:0 0 6px ${statusHex(n.status)};"></span>
                    <span class="sr-name">${escapeHTML(n.name || n.id)}</span>
                    <span class="sr-type">${escapeHTML(typeLabel)}</span>
                </div>
            `;
        }).join('');
        this.results.classList.add('visible');
        this.results.querySelectorAll('[data-id]').forEach(el => {
            el.addEventListener('click', () => {
                this.engine.selection.select(el.dataset.id);
                this.engine.centerNode(el.dataset.id);
                this.results.classList.remove('visible');
            });
        });
    }

    _onKey(e) {
        if (e.key === 'Escape') {
            this.input.value = '';
            this.results.classList.remove('visible');
            this.engine.selection.clearHighlight();
        } else if (e.key === 'Enter') {
            const first = this.results.querySelector('[data-id]');
            if (first) first.click();
        }
    }
}

function escapeHTML(s) {
    return String(s ?? '')
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function escapeAttr(s) { return escapeHTML(s).replace(/'/g,'&#39;'); }
