import { LAYOUTS } from '../utils/Constants.js';

/**
 * Center toolbar: layout switcher, fit, reset, toggle labels, simulate failure.
 * Kept intentionally dumb — it emits high-level actions on the bus.
 */
export class Toolbar {
    constructor({ root, engine, bus }) {
        this.root = root;
        this.engine = engine;
        this.bus = bus;
        this._render();
    }

    _render() {
        const layoutBtns = LAYOUTS.map(l => `
            <button class="tool-btn ${l.id === this.engine.layoutMode ? 'active' : ''}" data-layout="${l.id}">${l.label}</button>
        `).join('');

        this.root.innerHTML = `
            <div class="tool-btn-group" style="display:flex;gap:4px;">
                ${layoutBtns}
            </div>
            <div class="tool-sep"></div>
            <button class="tool-btn" data-act="fit">◱ Fit</button>
            <button class="tool-btn" data-act="reset">↺ Reset</button>
            <button class="tool-btn" data-act="labels">Aa Labels</button>
            <div class="tool-sep"></div>
            <button class="tool-btn" data-act="fail-random" title="Kill a random node to see impact">⚡ Simulate Failure</button>
            <button class="tool-btn" data-act="restore-all">✓ Restore All</button>
        `;

        this.root.querySelectorAll('[data-layout]').forEach(btn => {
            btn.addEventListener('click', () => {
                this.root.querySelectorAll('[data-layout]').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.engine.setLayout(btn.dataset.layout);
                const el = document.getElementById('hud-layout');
                if (el) el.textContent = btn.dataset.layout;
            });
        });
        this.root.querySelectorAll('[data-act]').forEach(btn => {
            btn.addEventListener('click', () => this._act(btn.dataset.act));
        });
    }

    _act(act) {
        switch (act) {
            case 'fit':   this.engine.fitGraph(); break;
            case 'reset': this.engine.cameraController.reset(); break;
            case 'labels': {
                const v = !this.engine.labelRenderer.visible;
                this.engine.labelRenderer.setVisible(v);
                break;
            }
            case 'fail-random': {
                const eligible = this.engine.nodes.filter(n => n.status !== 'down' && n.status !== 'critical' && n.type !== 'region');
                if (!eligible.length) return;
                const victim = eligible[Math.floor(Math.random() * eligible.length)];
                this.engine.failNode(victim.id);
                this.engine.selection.select(victim.id);
                this.bus.emit('toast', {
                    kind: 'crit',
                    msg: `Simulated failure of "${victim.name || victim.id}" — check right panel for impact.`
                });
                break;
            }
            case 'restore-all': {
                for (const n of this.engine.nodes) {
                    if (n.status === 'down' || n.status === 'critical') {
                        n.status = n._originalStatus || 'healthy';
                    }
                }
                this.engine.selection.recomputeFailures();
                this.engine.nodeRenderer.refreshStatus();
                this.bus.emit('toast', { kind: 'good', msg: 'All nodes restored to healthy state.' });
                break;
            }
        }
    }
}
