import { NODE_TYPES, STATUS_META } from '../utils/Constants.js';
import { statusHex } from '../utils/Colors.js';

/**
 * Right-side floating panel: shows name, type, status, properties, relations
 * and — critically — an impact summary when the selected node is failed or
 * impacted (so the user sees "which flows stopped, which nodes were affected").
 */
export class InfoPanel {
    constructor({ root, engine, bus }) {
        this.root = root;
        this.engine = engine;
        this.bus = bus;
        this.currentId = null;

        bus.on('selectionChanged', (ids) => {
            if (ids.length === 1) this.showNode(ids[0]);
            else if (ids.length === 0) this.hide();
        });
        bus.on('failuresChanged', () => {
            if (this.currentId) this.showNode(this.currentId);
        });
    }

    hide() {
        this.currentId = null;
        this.root.classList.add('hidden');
    }

    showNode(id) {
        const n = this.engine.getNode(id);
        if (!n) return this.hide();
        this.currentId = id;
        this.root.classList.remove('hidden');
        this.root.innerHTML = this._render(n);
        this._bindEvents(n);
    }

    _render(n) {
        const typeMeta = NODE_TYPES[n.type] || NODE_TYPES.unknown;
        const status = n.status || 'unknown';
        const stMeta = STATUS_META[status] || STATUS_META.unknown;
        const stColor = statusHex(status);

        const state = this.engine.selection.getState();
        const isFailed = state.failed.has(n.id);
        const isImpacted = state.impacted.has(n.id);

        const props = n.properties || {};
        const propKeys = Object.keys(props);

        const outgoing = this.engine.links.filter(l => l.source.id === n.id);
        const incoming = this.engine.links.filter(l => l.target.id === n.id);

        // impacted downstream (nodes reachable from this node that are impacted/failed)
        let impactSection = '';
        if (isFailed) {
            const affected = [...state.impacted];
            const deadRelated = this.engine.links.filter(l =>
                (l.source.id === n.id || l.target.id === n.id));
            impactSection = `
                <div class="ip-impact">
                    <div class="ip-impact-title">⚠ Failure impact</div>
                    <div class="ip-impact-body">
                        ${affected.length
                            ? `<strong>${affected.length}</strong> downstream node${affected.length===1?'':'s'} affected.`
                            : `No downstream dependents detected.`}
                    </div>
                    <div>
                        ${affected.slice(0, 10).map(id => {
                            const t = this.engine.getNode(id);
                            return `<span class="ip-impact-chip" data-goto="${escapeAttr(id)}">${escapeHTML(t?.name || id)}</span>`;
                        }).join('')}
                        ${affected.length > 10 ? `<span class="ip-impact-chip">+${affected.length-10} more</span>` : ''}
                    </div>
                    <div style="margin-top:6px;">
                        <strong>${deadRelated.length}</strong> connection${deadRelated.length===1?'':'s'} stopped from this node.
                    </div>
                </div>`;
        } else if (isImpacted) {
            // find which failed upstream node causes this
            const upstream = [...state.failed].filter(fid => this._reachable(fid, n.id));
            impactSection = `
                <div class="ip-impact" style="background:linear-gradient(90deg, rgba(217,154,28,0.14), rgba(217,154,28,0.04));border-color:rgba(217,154,28,0.35);color:var(--warn);">
                    <div class="ip-impact-title">Impacted by upstream failure</div>
                    <div class="ip-impact-body">This node is affected because a dependency is down.</div>
                    <div>
                        ${upstream.map(id => {
                            const t = this.engine.getNode(id);
                            return `<span class="ip-impact-chip" data-goto="${escapeAttr(id)}" style="border-color:rgba(217,154,28,0.4);color:var(--warn);">${escapeHTML(t?.name || id)}</span>`;
                        }).join('') || '<em>(unknown source)</em>'}
                    </div>
                </div>`;
        }

        // metric bars for common properties
        const metrics = ['cpu', 'memory', 'disk', 'load', 'requests', 'latency']
            .filter(k => typeof props[k] === 'number')
            .map(k => {
                const v = Math.max(0, Math.min(100, props[k]));
                return `
                    <div class="ip-metric">
                        <div class="ip-metric-row">
                            <span>${k.toUpperCase()}</span>
                            <span class="val">${props[k]}${['cpu','memory','disk','load'].includes(k) ? '%' : ''}</span>
                        </div>
                        <div class="ip-metric-bar"><div class="ip-metric-fill" style="width:${v}%"></div></div>
                    </div>`;
            }).join('');

        const otherProps = propKeys.filter(k => !['cpu','memory','disk','load','requests','latency'].includes(k));

        return `
            <div class="ip-header">
                <div class="ip-type-row">
                    <span class="ip-type-badge">${escapeHTML(typeMeta.label)}</span>
                    <span>${escapeHTML(stMeta.label)}</span>
                    <button class="ip-close" data-act="close" title="Close">✕</button>
                </div>
                <div class="ip-title">
                    <span class="ip-status-dot" style="background:${stColor};color:${stColor};"></span>
                    ${escapeHTML(n.name || n.id)}
                </div>
                <div class="ip-subtitle">${escapeHTML(n.id)}</div>
            </div>

            <div class="ip-body">
                ${impactSection}

                ${metrics ? `<div class="ip-section">
                    <div class="ip-section-title">Metrics</div>
                    ${metrics}
                </div>` : ''}

                ${otherProps.length ? `<div class="ip-section">
                    <div class="ip-section-title">Properties <span class="ip-section-count">${otherProps.length}</span></div>
                    <div class="ip-props">
                        ${otherProps.map(k => `
                            <div class="ip-prop">
                                <div class="ip-prop-key">${escapeHTML(k)}</div>
                                <div class="ip-prop-val" title="${escapeAttr(String(props[k]))}">${escapeHTML(String(props[k]))}</div>
                            </div>`).join('')}
                    </div>
                </div>` : ''}

                ${outgoing.length ? `<div class="ip-section">
                    <div class="ip-section-title">Depends on / Connects to <span class="ip-section-count">${outgoing.length}</span></div>
                    ${outgoing.map(l => this._relRow(l, 'target')).join('')}
                </div>` : ''}

                ${incoming.length ? `<div class="ip-section">
                    <div class="ip-section-title">Consumed by <span class="ip-section-count">${incoming.length}</span></div>
                    ${incoming.map(l => this._relRow(l, 'source')).join('')}
                </div>` : ''}
            </div>

            <div class="ip-actions">
                <button class="ip-btn" data-act="expand">＋ Expand</button>
                <button class="ip-btn" data-act="collapse">− Collapse</button>
                <button class="ip-btn" data-act="center">◎ Center</button>
                <button class="ip-btn" data-act="deps">↗ Show Deps</button>
                ${isFailed
                    ? `<button class="ip-btn primary" data-act="restore">↺ Restore</button>`
                    : `<button class="ip-btn danger" data-act="fail">⚠ Simulate Failure</button>`}
                <button class="ip-btn" data-act="hide">Hide</button>
            </div>
        `;
    }

    _relRow(l, endSide) {
        const other = endSide === 'target' ? l.target : l.source;
        return `
            <div class="ip-rel" data-goto="${escapeAttr(other.id)}">
                <span class="ip-rel-type">${escapeHTML(l.type)}</span>
                <span class="ip-rel-arrow">${endSide === 'target' ? '→' : '←'}</span>
                <span class="ip-rel-name">${escapeHTML(other.name || other.id)}</span>
                <span class="ip-rel-status" style="background:${statusHex(other.status)};color:${statusHex(other.status)};"></span>
            </div>`;
    }

    _reachable(fromId, toId) {
        const seen = new Set([fromId]);
        const q = [fromId];
        while (q.length) {
            const cur = q.shift();
            if (cur === toId) return true;
            for (const l of this.engine.links) {
                const s = l.source.id, t = l.target.id;
                if (s === cur && !seen.has(t)) { seen.add(t); q.push(t); }
            }
        }
        return false;
    }

    _bindEvents(n) {
        this.root.querySelectorAll('[data-goto]').forEach(el => {
            el.addEventListener('click', () => this.engine.selection.select(el.dataset.goto));
        });
        this.root.querySelectorAll('[data-act]').forEach(el => {
            el.addEventListener('click', () => {
                const act = el.dataset.act;
                switch (act) {
                    case 'close':    this.engine.selection.clearSelection(); break;
                    case 'expand':   this.engine.expandNode(n.id); break;
                    case 'collapse': this.engine.collapseNode(n.id); break;
                    case 'center':   this.engine.centerNode(n.id); break;
                    case 'deps':     this._showDeps(n.id); break;
                    case 'fail':     this.engine.failNode(n.id); break;
                    case 'restore':  this.engine.restoreNode(n.id); break;
                    case 'hide':     this.hide(); break;
                }
            });
        });
    }

    _showDeps(id) {
        // highlight outgoing neighbourhood: nodes that this node depends on/reaches
        const seen = new Set([id]);
        const q = [id];
        while (q.length) {
            const cur = q.shift();
            for (const l of this.engine.links) {
                if (l.source.id === cur && !seen.has(l.target.id)) { seen.add(l.target.id); q.push(l.target.id); }
            }
        }
        this.engine.selection.highlight([...seen]);
        this.engine.cameraController.fitTo([...seen].map(id => this.engine.getNode(id)).filter(Boolean));
    }
}

function escapeHTML(s) {
    return String(s ?? '')
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function escapeAttr(s) { return escapeHTML(s).replace(/'/g,'&#39;'); }
