import { GraphEngine } from './core/GraphEngine.js';
import { Toolbar } from './ui/Toolbar.js';
import { InfoPanel } from './ui/InfoPanel.js';
import { SearchPanel } from './ui/SearchPanel.js';
import { sampleData, sampleFetchChildren } from '../data/sample-data.js';

const savedTheme = localStorage.getItem('q3d-theme') || 'light';
document.body.setAttribute('data-theme', savedTheme);

const engine = new GraphEngine({
    container: '#graph',
    labelsRoot: '#labels-root',
    data: sampleData,
    layout: 'force',
    theme: savedTheme,
    fetchChildren: sampleFetchChildren
});

new Toolbar({ root: document.getElementById('toolbar'), engine, bus: engine.bus });
new InfoPanel({ root: document.getElementById('info-panel'), engine, bus: engine.bus });
new SearchPanel({
    input: document.getElementById('search-input'),
    results: document.getElementById('search-results'),
    engine,
    bus: engine.bus
});

const hudNodes = document.getElementById('hud-nodes');
const hudLinks = document.getElementById('hud-links');
const hudFps = document.getElementById('hud-fps');
const hudLayout = document.getElementById('hud-layout');
const loader = document.getElementById('loader');
const toastRoot = document.getElementById('toast-root');

engine.bus.on('graphLoaded', ({ nodes, links }) => {
    hudNodes.textContent = nodes;
    hudLinks.textContent = links;
    hudLayout.textContent = engine.layoutMode;
    loader?.classList.add('hidden');
    loader?.style.setProperty('display', 'none');
});
engine.bus.on('fps', (fps) => { hudFps.textContent = fps; });
engine.bus.on('toast', ({ kind = 'info', msg = '' }) => {
    if (!toastRoot) return;
    const el = document.createElement('div');
    el.className = `toast toast-${kind}`;
    el.textContent = msg;
    toastRoot.appendChild(el);
    setTimeout(() => el.classList.add('show'), 10);
    setTimeout(() => {
        el.classList.remove('show');
        setTimeout(() => el.remove(), 400);
    }, 3800);
});

document.querySelectorAll('#theme-switcher [data-theme]').forEach(btn => {
    btn.addEventListener('click', () => {
        const name = btn.dataset.theme;
        document.querySelectorAll('#theme-switcher [data-theme]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.body.setAttribute('data-theme', name);
        localStorage.setItem('q3d-theme', name);
        engine.setTheme(name);
    });
    if (btn.dataset.theme === savedTheme) {
        document.querySelectorAll('#theme-switcher [data-theme]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
    }
});

engine.load().catch(err => {
    console.error('[Q3D] failed to load graph', err);
    loader?.querySelector('.loader-text')?.replaceChildren(document.createTextNode('Failed to load — see console.'));
});

window.q3d = engine;
