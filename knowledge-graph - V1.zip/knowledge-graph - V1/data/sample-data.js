/**
 * Sample infrastructure graph. Includes:
 *  - regions, VPCs, subnets, VMs, DBs, storage, load balancers, services, users
 *  - at least one node with `status: 'down'` so the failure/impact overlay
 *    lights up on first load (per the user's request to see which flows stop
 *    and which nodes are affected).
 */

const nodes = [
    // Regions
    { id: 'r-east', type: 'region', name: 'US-East-1', status: 'healthy' },
    { id: 'r-west', type: 'region', name: 'US-West-2', status: 'healthy' },

    // VPCs
    { id: 'vpc-prod', type: 'vpc', name: 'Prod-VPC', status: 'healthy', properties: { cidr: '10.0.0.0/16' } },
    { id: 'vpc-dr',   type: 'vpc', name: 'DR-VPC',   status: 'healthy', properties: { cidr: '10.1.0.0/16' } },

    // Subnets
    { id: 'sn-web-a',  type: 'subnet', name: 'Web-Subnet-A',  status: 'healthy', zone: 'prod-web' },
    { id: 'sn-web-b',  type: 'subnet', name: 'Web-Subnet-B',  status: 'healthy', zone: 'prod-web' },
    { id: 'sn-app-a',  type: 'subnet', name: 'App-Subnet-A',  status: 'healthy', zone: 'prod-app' },
    { id: 'sn-app-b',  type: 'subnet', name: 'App-Subnet-B',  status: 'warning', zone: 'prod-app' },
    { id: 'sn-db',     type: 'subnet', name: 'DB-Subnet',     status: 'healthy', zone: 'prod-db' },
    { id: 'sn-dr',     type: 'subnet', name: 'DR-Subnet',     status: 'healthy', zone: 'dr' },

    // Load Balancers / Gateway
    { id: 'igw-1',  type: 'gateway',      name: 'Internet-GW', status: 'healthy', zone: 'edge' },
    { id: 'alb-1',  type: 'loadbalancer', name: 'Web-ALB',     status: 'healthy', zone: 'edge',
      properties: { requests: 82, latency: 34 } },
    { id: 'alb-2',  type: 'loadbalancer', name: 'App-ALB',     status: 'overloaded', zone: 'edge',
      properties: { requests: 96, latency: 78 } },

    // Web servers
    { id: 'web-1', type: 'vm', name: 'web-01', status: 'healthy',   zone: 'prod-web', properties: { cpu: 22, memory: 41, disk: 30 } },
    { id: 'web-2', type: 'vm', name: 'web-02', status: 'healthy',   zone: 'prod-web', properties: { cpu: 27, memory: 45, disk: 28 } },
    { id: 'web-3', type: 'vm', name: 'web-03', status: 'warning',   zone: 'prod-web', properties: { cpu: 71, memory: 63, disk: 55 } },

    // App / service tier
    { id: 'app-1', type: 'vm', name: 'app-01', status: 'healthy',   zone: 'prod-app', properties: { cpu: 48, memory: 55, disk: 40 } },
    { id: 'app-2', type: 'vm', name: 'app-02', status: 'healthy',   zone: 'prod-app', properties: { cpu: 51, memory: 58, disk: 42 } },
    // >>> This is the failed node we'll demo. Multiple downstream nodes depend on it.
    { id: 'app-3', type: 'vm', name: 'app-03', status: 'down',      zone: 'prod-app',
      properties: { cpu: 0, memory: 0, disk: 0, role: 'orders-service' } },

    // Microservices (containers)
    { id: 'svc-auth',    type: 'service', name: 'auth-svc',    status: 'healthy',   zone: 'prod-app', properties: { requests: 34 } },
    { id: 'svc-orders',  type: 'service', name: 'orders-svc',  status: 'critical',  zone: 'prod-app', properties: { requests: 0 } },
    { id: 'svc-payment', type: 'service', name: 'payment-svc', status: 'warning',   zone: 'prod-app', properties: { requests: 12 } },
    { id: 'svc-catalog', type: 'service', name: 'catalog-svc', status: 'healthy',   zone: 'prod-app', properties: { requests: 61 } },

    // Databases
    { id: 'db-primary', type: 'database', name: 'orders-db',    status: 'healthy',  zone: 'prod-db',
      properties: { cpu: 62, memory: 74, disk: 46, connections: 231, engine: 'postgres 14' } },
    { id: 'db-replica', type: 'database', name: 'orders-db-r1', status: 'healthy',  zone: 'prod-db',
      properties: { cpu: 41, memory: 60, disk: 46, connections: 88, engine: 'postgres 14' } },
    { id: 'db-cache',   type: 'database', name: 'cache-redis',  status: 'healthy',  zone: 'prod-db',
      properties: { cpu: 22, memory: 38, engine: 'redis 7' } },

    // Storage
    { id: 'st-s3',   type: 'storage', name: 'assets-bucket', status: 'healthy', zone: 'edge', properties: { size: '4.2 TB', tier: 'standard' } },
    { id: 'st-logs', type: 'storage', name: 'logs-bucket',   status: 'healthy', zone: 'edge', properties: { size: '18 TB',  tier: 'infrequent' } },

    // DR
    { id: 'db-dr', type: 'database', name: 'orders-db-dr', status: 'maintenance', zone: 'dr',
      properties: { cpu: 4, memory: 12, engine: 'postgres 14' } },
    { id: 'web-dr', type: 'vm', name: 'web-dr-01', status: 'maintenance', zone: 'dr',
      properties: { cpu: 3, memory: 10 } },

    // Users (traffic source)
    { id: 'user-web',    type: 'user', name: 'Web Users',    status: 'healthy' },
    { id: 'user-mobile', type: 'user', name: 'Mobile Users', status: 'healthy' }
];

const relations = [
    // region -> vpc
    { source: 'r-east', target: 'vpc-prod', type: 'contains' },
    { source: 'r-west', target: 'vpc-dr',   type: 'contains' },

    // vpc -> subnets
    { source: 'vpc-prod', target: 'sn-web-a', type: 'contains' },
    { source: 'vpc-prod', target: 'sn-web-b', type: 'contains' },
    { source: 'vpc-prod', target: 'sn-app-a', type: 'contains' },
    { source: 'vpc-prod', target: 'sn-app-b', type: 'contains' },
    { source: 'vpc-prod', target: 'sn-db',    type: 'contains' },
    { source: 'vpc-dr',   target: 'sn-dr',    type: 'contains' },

    // hosts (subnet hosts vm/service)
    { source: 'sn-web-a', target: 'web-1', type: 'hosts' },
    { source: 'sn-web-a', target: 'web-2', type: 'hosts' },
    { source: 'sn-web-b', target: 'web-3', type: 'hosts' },
    { source: 'sn-app-a', target: 'app-1', type: 'hosts' },
    { source: 'sn-app-a', target: 'app-2', type: 'hosts' },
    { source: 'sn-app-b', target: 'app-3', type: 'hosts' },
    { source: 'sn-db',    target: 'db-primary', type: 'hosts' },
    { source: 'sn-db',    target: 'db-replica', type: 'hosts' },
    { source: 'sn-db',    target: 'db-cache',   type: 'hosts' },
    { source: 'sn-dr',    target: 'db-dr',      type: 'hosts' },
    { source: 'sn-dr',    target: 'web-dr',     type: 'hosts' },

    // user traffic -> gateway -> load balancers -> web
    { source: 'user-web',    target: 'igw-1', type: 'connectsTo' },
    { source: 'user-mobile', target: 'igw-1', type: 'connectsTo' },
    { source: 'igw-1',       target: 'alb-1', type: 'routes' },
    { source: 'igw-1',       target: 'alb-2', type: 'routes' },
    { source: 'alb-1', target: 'web-1', type: 'routes' },
    { source: 'alb-1', target: 'web-2', type: 'routes' },
    { source: 'alb-1', target: 'web-3', type: 'routes' },

    // web -> services / app tier
    { source: 'web-1', target: 'svc-auth',    type: 'dependsOn' },
    { source: 'web-2', target: 'svc-auth',    type: 'dependsOn' },
    { source: 'web-1', target: 'svc-catalog', type: 'dependsOn' },
    { source: 'web-2', target: 'svc-orders',  type: 'dependsOn' },
    { source: 'web-3', target: 'svc-orders',  type: 'dependsOn' },
    { source: 'web-1', target: 'svc-payment', type: 'dependsOn' },
    { source: 'web-2', target: 'svc-payment', type: 'dependsOn' },

    // app-3 hosts orders-svc — so when app-3 goes down, orders-svc collapses,
    // and web-2/web-3 (which depend on orders-svc) become impacted.
    { source: 'app-3', target: 'svc-orders',  type: 'hosts' },
    { source: 'app-1', target: 'svc-auth',    type: 'hosts' },
    { source: 'app-2', target: 'svc-catalog', type: 'hosts' },
    { source: 'app-2', target: 'svc-payment', type: 'hosts' },

    // services -> databases
    { source: 'svc-orders',  target: 'db-primary', type: 'dependsOn' },
    { source: 'svc-catalog', target: 'db-primary', type: 'dependsOn' },
    { source: 'svc-payment', target: 'db-primary', type: 'dependsOn' },
    { source: 'svc-auth',    target: 'db-cache',   type: 'dependsOn' },

    // replicas
    { source: 'db-primary', target: 'db-replica', type: 'replicatesTo' },
    { source: 'db-primary', target: 'db-dr',      type: 'replicatesTo' },

    // storage
    { source: 'web-1', target: 'st-s3', type: 'connectsTo' },
    { source: 'web-2', target: 'st-s3', type: 'connectsTo' },
    { source: 'app-1', target: 'st-logs', type: 'connectsTo' },
    { source: 'app-2', target: 'st-logs', type: 'connectsTo' },
    { source: 'app-3', target: 'st-logs', type: 'connectsTo' },

    // ALB-2 talks to app tier
    { source: 'alb-2', target: 'app-1', type: 'routes' },
    { source: 'alb-2', target: 'app-2', type: 'routes' },
    { source: 'alb-2', target: 'app-3', type: 'routes' }
];

export const sampleData = { nodes, relations };

/**
 * Fake async fetchChildren — for demonstrating lazy expand. If a user
 * expands a database node, we produce a few "table" child nodes.
 */
export async function sampleFetchChildren(parentId) {
    await new Promise(r => setTimeout(r, 220));
    if (parentId === 'db-primary') {
        return {
            nodes: [
                { id: 'tbl-orders',  type: 'container', name: 'orders',   status: 'healthy', properties: { rows: '12.4M' } },
                { id: 'tbl-users',   type: 'container', name: 'users',    status: 'healthy', properties: { rows: '2.1M' } },
                { id: 'tbl-events',  type: 'container', name: 'events',   status: 'warning', properties: { rows: '284M' } }
            ],
            relations: [
                { source: 'db-primary', target: 'tbl-orders',  type: 'contains' },
                { source: 'db-primary', target: 'tbl-users',   type: 'contains' },
                { source: 'db-primary', target: 'tbl-events',  type: 'contains' }
            ]
        };
    }
    return { nodes: [], relations: [] };
}
